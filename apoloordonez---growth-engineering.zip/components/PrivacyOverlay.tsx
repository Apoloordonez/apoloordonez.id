import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { X, ShieldCheck, Lock, Server, Eye, ChevronRight, FileText } from 'lucide-react';

interface PrivacyOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

const SECTIONS = [
  {
    id: 'intro',
    title: 'Protocolo de Inicio',
    content: 'En ApoloOrdonez Growth Engineering, la privacidad no es una ocurrencia tardía; es parte de nuestra arquitectura base. Este documento detalla los protocolos técnicos y legales utilizados para proteger la integridad de sus datos corporativos.'
  },
  {
    id: 'collection',
    title: '1. Ingesta de Datos',
    content: 'Recopilamos información estrictamente necesaria para la ejecución de auditorías y estrategias de crecimiento. Esto incluye: Identificadores corporativos (Email, Dominio), Métricas de rendimiento (vía APIs autorizadas de Meta/Google) y Datos de comportamiento en sitio. No utilizamos trackers ocultos ni vendemos datos a terceros.'
  },
  {
    id: 'security',
    title: '2. Encriptación & Seguridad',
    content: 'Toda la transmisión de datos se realiza bajo protocolo TLS 1.3. Los datos en reposo están encriptados utilizando el estándar AES-256. Nuestra infraestructura se aloja en servidores con certificación SOC 2 Tipo II, garantizando la máxima resiliencia contra accesos no autorizados.'
  },
  {
    id: 'ai-usage',
    title: '3. Procesamiento con IA',
    content: 'Utilizamos modelos de Inteligencia Artificial (LLMs) para el análisis de datos y generación de estrategias. Sus datos se anonimizan antes de ser procesados. Importante: Sus datos NUNCA se utilizan para entrenar modelos públicos de terceros sin su consentimiento explícito por escrito.'
  },
  {
    id: 'rights',
    title: '4. Derechos del Usuario (ARCO)',
    content: 'Usted mantiene la soberanía total sobre sus datos. Puede solicitar Acceso, Rectificación, Cancelación u Oposición en cualquier momento. Al invocar el "Derecho al Olvido", eliminaremos permanentemente sus registros de nuestros sistemas, manteniendo solo lo legalmente obligatorio para fines fiscales.'
  },
  {
    id: 'cookies',
    title: '5. Telemetría & Cookies',
    content: 'Empleamos almacenamiento local y cookies técnicas para mantener la sesión de usuario y preferencias de configuración. Las cookies de análisis son opcionales y se activan solo bajo su aprobación explícita en el panel de control de cookies.'
  }
];

const PrivacyOverlay: React.FC<PrivacyOverlayProps> = ({ isOpen, onClose }) => {
  const [activeSection, setActiveSection] = useState(SECTIONS[0].id);

  // Close on Escape key
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  // Lock body scroll when open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
  }, [isOpen]);

  const scrollToSection = (id: string) => {
    setActiveSection(id);
    const element = document.getElementById(`privacy-${id}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: '100%' }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="fixed inset-0 z-[100] flex flex-col bg-brand-dark/95 backdrop-blur-xl overflow-hidden"
    >
      {/* Background Grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808008_1px,transparent_1px),linear-gradient(to_bottom,#80808008_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none"></div>

      {/* Top Bar */}
      <div className="relative z-10 flex items-center justify-between px-6 py-4 border-b border-white/10 bg-brand-dark/50">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-brand-accent/10 rounded-lg border border-brand-accent/20">
            <ShieldCheck className="w-5 h-5 text-brand-accent animate-pulse" />
          </div>
          <div>
            <h2 className="text-white font-mono font-bold tracking-tight">LEGAL PROTOCOLS</h2>
            <p className="text-[10px] text-gray-500 font-mono uppercase tracking-widest">Secure Data Vault v2.4</p>
          </div>
        </div>
        
        <button 
          onClick={onClose}
          className="p-2 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition-colors group border border-transparent hover:border-white/10"
        >
          <X className="w-6 h-6 group-hover:rotate-90 transition-transform duration-300" />
        </button>
      </div>

      {/* Main Layout */}
      <div className="flex-1 flex overflow-hidden relative z-10">
        
        {/* Sidebar Navigation (Desktop) */}
        <div className="hidden lg:block w-1/4 min-w-[300px] border-r border-white/10 p-6 overflow-y-auto bg-black/20">
          <div className="mb-8">
            <p className="text-xs font-mono text-gray-500 mb-4 uppercase tracking-wider">Índice de Contenidos</p>
            <nav className="space-y-1">
              {SECTIONS.map((section) => (
                <button
                  key={section.id}
                  onClick={() => scrollToSection(section.id)}
                  className={`w-full text-left px-4 py-3 rounded-lg text-sm font-medium transition-all flex items-center justify-between group ${
                    activeSection === section.id 
                      ? 'bg-brand-accent/10 text-brand-accent border border-brand-accent/20' 
                      : 'text-gray-400 hover:bg-white/5 hover:text-white border border-transparent'
                  }`}
                >
                  <span className="truncate mr-2">{section.title}</span>
                  {activeSection === section.id && (
                    <motion.div layoutId="activeIndicator">
                      <ChevronRight className="w-4 h-4" />
                    </motion.div>
                  )}
                </button>
              ))}
            </nav>
          </div>

          {/* Quick Stats */}
          <div className="p-4 rounded-xl bg-white/5 border border-white/5 space-y-3">
            <div className="flex items-center gap-3 text-xs text-gray-400">
              <Lock className="w-4 h-4 text-emerald-500" />
              <span>AES-256 Encryption Active</span>
            </div>
            <div className="flex items-center gap-3 text-xs text-gray-400">
              <Server className="w-4 h-4 text-blue-500" />
              <span>Data Resident: AWS US-East</span>
            </div>
            <div className="flex items-center gap-3 text-xs text-gray-400">
              <Eye className="w-4 h-4 text-brand-accent" />
              <span>No Third-Party Tracking</span>
            </div>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto scroll-smooth p-6 lg:p-12 relative">
            <div className="max-w-3xl mx-auto">
                {/* Trust Header */}
                <div className="mb-12 p-6 rounded-2xl bg-gradient-to-br from-brand-accent/5 to-transparent border border-brand-accent/20">
                    <div className="flex items-start gap-4">
                        <FileText className="w-8 h-8 text-brand-accent shrink-0 mt-1" />
                        <div>
                            <h1 className="text-2xl md:text-3xl font-bold text-white mb-2">Política de Privacidad y Tratamiento de Datos</h1>
                            <p className="text-gray-400 text-sm leading-relaxed">
                                Última actualización: <span className="text-brand-accent font-mono">{new Date().toLocaleDateString()}</span>
                            </p>
                            <div className="mt-4 flex flex-wrap gap-2">
                                <span className="px-2 py-1 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-mono">GDPR Compliant</span>
                                <span className="px-2 py-1 rounded bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-mono">CCPA Ready</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Sections */}
                <div className="space-y-16">
                    {SECTIONS.map((section) => (
                        <div key={section.id} id={`privacy-${section.id}`} className="scroll-mt-24">
                            <h3 className="text-xl font-mono text-white mb-4 flex items-center gap-3">
                                <span className="w-1.5 h-6 bg-brand-accent rounded-full"></span>
                                {section.title}
                            </h3>
                            <div className="prose prose-invert prose-p:text-gray-300 prose-p:font-sans prose-p:leading-7 max-w-none">
                                <p>{section.content}</p>
                            </div>
                            
                            {/* Callout Example for Security Section */}
                            {section.id === 'security' && (
                                <div className="mt-6 p-4 border-l-2 border-brand-accent bg-brand-accent/5 rounded-r-lg">
                                    <p className="text-sm text-brand-accent font-medium m-0">
                                        System Note: Realizamos auditorías de vulnerabilidad trimestrales para asegurar la integridad de la infraestructura.
                                    </p>
                                </div>
                            )}
                        </div>
                    ))}
                </div>

                {/* Footer Signature */}
                <div className="mt-20 pt-10 border-t border-white/10 text-center">
                    <p className="text-gray-500 text-sm">
                        Si tiene dudas sobre este protocolo, contacte directamente al equipo de Compliance: <br />
                        <a href="mailto:legal@apoloordonez.com" className="text-brand-accent hover:underline mt-2 inline-block">legal@apoloordonez.com</a>
                    </p>
                </div>
            </div>
        </div>
      </div>
    </motion.div>
  );
};

export default PrivacyOverlay;
