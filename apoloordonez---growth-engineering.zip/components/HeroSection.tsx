import React, { useEffect, useRef, useState } from 'react';
import { motion, useInView, animate, AnimatePresence } from 'framer-motion';
import { ArrowRight, ChevronDown } from 'lucide-react';
import { ROTATING_FOCUS, ROTATING_STACK } from '../constants';

// --- Sub-component: Animated Counter ---
const AnimatedCounter = ({ from = 0, to, prefix = '', suffix = '', duration = 2 }: { from?: number, to: number, prefix?: string, suffix?: string, duration?: number }) => {
  const nodeRef = useRef<HTMLSpanElement>(null);
  const isInView = useInView(nodeRef, { once: true, margin: "-100px" });

  useEffect(() => {
    if (!isInView) return;

    const node = nodeRef.current;
    const controls = animate(from, to, {
      duration: duration,
      ease: "easeOut",
      onUpdate(value) {
        if (node) {
          node.textContent = `${prefix}${Math.round(value)}${suffix}`;
        }
      },
    });

    return () => controls.stop();
  }, [from, to, prefix, suffix, duration, isInView]);

  return <span ref={nodeRef} className="tabular-nums" />;
};

// --- Sub-component: Text Rotator ---
const TextRotator = ({ items, className = "" }: { items: string[], className?: string }) => {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((prev) => (prev + 1) % items.length);
    }, 2500); // Rotate every 2.5 seconds
    return () => clearInterval(timer);
  }, [items]);

  return (
    <div className="relative min-h-[3rem] w-full flex justify-center items-center overflow-hidden">
      <AnimatePresence mode="wait">
        <motion.span
          key={index}
          initial={{ y: 20, opacity: 0, filter: 'blur(5px)' }}
          animate={{ y: 0, opacity: 1, filter: 'blur(0px)' }}
          exit={{ y: -20, opacity: 0, filter: 'blur(5px)' }}
          transition={{ duration: 0.5, ease: "easeInOut" }}
          className={`w-full text-center font-mono font-bold whitespace-nowrap ${className}`}
        >
          {items[index]}
        </motion.span>
      </AnimatePresence>
    </div>
  );
};

const HeroSection: React.FC = () => {
  const handleScrollTo = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    e.preventDefault();
    const element = document.getElementById(targetId);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section className="relative min-h-[100dvh] flex flex-col justify-center pt-32 pb-16 overflow-x-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_10%,_rgba(102,252,241,0.05),transparent_50%)] pointer-events-none"></div>
      <div className="absolute top-0 left-0 w-full h-full bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 brightness-100 contrast-150 pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center flex-grow flex flex-col justify-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 mb-6 sm:mb-8 backdrop-blur-sm">
            <span className="w-2 h-2 rounded-full bg-brand-accent animate-pulse"></span>
            <span className="text-[10px] sm:text-xs font-mono text-brand-accent tracking-wide">SYSTEMS OVER HACKS</span>
          </div>
          
          <h1 className="text-4xl sm:text-5xl md:text-7xl font-bold tracking-tight text-white mb-6 leading-[1.1]">
            Ingeniería de Crecimiento & <br className="hidden sm:block" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-accent to-blue-500 block sm:inline mt-2 sm:mt-0">
              Ecosistemas de IA
            </span>
          </h1>
          
          <p className="mt-4 max-w-2xl mx-auto text-base sm:text-lg md:text-xl text-gray-400 font-light leading-relaxed px-2">
            Transformo el marketing digital en un <span className="text-white font-medium">centro de ingresos predecible</span>. 
            Estrategias validadas con data, no con supuestos.
          </p>

          <div className="mt-8 sm:mt-10 flex flex-col sm:flex-row justify-center gap-4 w-full sm:w-auto px-4 sm:px-0">
            <a 
              href="#services"
              onClick={(e) => handleScrollTo(e, 'services')}
              className="group relative inline-flex items-center justify-center px-8 py-3 overflow-hidden font-medium text-brand-dark bg-brand-accent rounded-lg shadow-lg shadow-brand-accent/20 transition-all hover:shadow-brand-accent/40 w-full sm:w-auto"
            >
              <span className="absolute inset-0 w-full h-full bg-gradient-to-br from-white/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200"></span>
              <span className="relative flex items-center gap-2">
                Explorar Soluciones <ArrowRight className="w-4 h-4" />
              </span>
            </a>
            <a 
              href="#expertise"
              onClick={(e) => handleScrollTo(e, 'expertise')}
              className="inline-flex items-center justify-center px-8 py-3 font-medium text-white border border-white/20 rounded-lg hover:bg-white/5 transition-all w-full sm:w-auto"
            >
              Ver Credenciales
            </a>
          </div>
        </motion.div>

        {/* Stats Strip */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="mt-16 sm:mt-20 pt-10 border-t border-white/5 grid grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-10"
        >
          {/* ROI Metric - Counter */}
          <div className="flex flex-col items-center justify-center p-2">
            <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-white font-mono">
              <AnimatedCounter from={0} to={700} prefix=">" suffix="%" duration={2.5} />
            </div>
            <span className="text-[10px] sm:text-xs text-gray-500 uppercase tracking-widest mt-1">ROI Promedio</span>
          </div>

          {/* Years Metric - Counter */}
          <div className="flex flex-col items-center justify-center p-2">
            <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-white font-mono">
              <AnimatedCounter from={0} to={7} prefix="+" suffix=" Años" duration={2} />
            </div>
            <span className="text-[10px] sm:text-xs text-gray-500 uppercase tracking-widest mt-1">Experiencia</span>
          </div>

          {/* Enfoque - Rotator */}
          <div className="flex flex-col items-center justify-center p-2 w-full overflow-visible">
            <TextRotator items={ROTATING_FOCUS} className="text-lg sm:text-xl md:text-2xl lg:text-3xl text-white" />
            <span className="text-[10px] sm:text-xs text-gray-500 uppercase tracking-widest mt-1">Enfoque</span>
          </div>

          {/* Stack - Rotator */}
          <div className="flex flex-col items-center justify-center p-2 w-full overflow-visible">
             <TextRotator items={ROTATING_STACK} className="text-lg sm:text-xl md:text-2xl lg:text-3xl text-white" />
            <span className="text-[10px] sm:text-xs text-gray-500 uppercase tracking-widest mt-1">Stack</span>
          </div>
        </motion.div>
      </div>

      <div className="hidden sm:block absolute bottom-10 left-1/2 transform -translate-x-1/2 text-gray-600 animate-bounce">
        <ChevronDown className="w-6 h-6" />
      </div>
    </section>
  );
};

export default HeroSection;