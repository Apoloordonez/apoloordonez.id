import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { SERVICES } from '../constants';
import { ServiceCategory, ServiceItem } from '../types';
import { 
  Check, 
  ArrowUpRight, 
  Calculator, 
  Bot, 
  Sparkles, 
  ChevronDown, 
  Clock,
  Square,
  CheckSquare,
  AlertCircle,
  CircleDollarSign,
  Users,
  Database,
  BarChart3,
  ScanLine,
  Activity,
  Cpu,
  MessageSquare,
  Mail,
  LineChart,
  Zap,
  MousePointerClick,
  Radar,
  AlertTriangle,
  CheckCircle2,
  Globe,
  TrendingUp
} from 'lucide-react';

// --- Helper for Radar Chart Math ---
const NUM_AXES = 5;
const MAX_VALUE = 5;
const RADIUS = 80; // Radius of the chart in SVG units
const CENTER = 110; // Center point (x,y) of the SVG viewBox

// Calculate x,y coordinates for a point on the radar
const getRadarPoint = (axisIndex: number, value: number) => {
  const angle = (Math.PI * 2 * axisIndex) / NUM_AXES - Math.PI / 2;
  const x = CENTER + RADIUS * (value / MAX_VALUE) * Math.cos(angle);
  const y = CENTER + RADIUS * (value / MAX_VALUE) * Math.sin(angle);
  return { x, y };
};

// --- Sub-component: Service Card with Logic ---
const ServiceCard: React.FC<{ service: ServiceItem; index: number }> = ({ service, index }) => {
  // Logic specifically for 'starter' service
  const isStarter = service.id === 'starter';
  const [starterChecks, setStarterChecks] = useState({
    budget: false,
    admin: false,
    asyncReport: false
  });

  // Logic specifically for 'market-fit' service
  const isMarketFit = service.id === 'market-fit';
  const [marketFitChecks, setMarketFitChecks] = useState({
    budget: false,
    traction: false,
    assets: false
  });

  // Logic specifically for 'business-scaling' service (The Infrastructure Scanner)
  const isBusinessScaling = service.id === 'business-scaling';
  const [scalingNodes, setScalingNodes] = useState({
    capital: false,
    human: false,
    tech: false,
    data: false
  });

  // Logic specifically for 'fractional-growth' service (Neural Network Builder)
  const isFractionalGrowth = service.id === 'fractional-growth';
  const [fractionalNodes, setFractionalNodes] = useState({
    sales: false,   // Agent 1
    support: false, // Agent 2
    bi: false,      // Agent 3
    email: false    // Agent 4
  });

  // Logic specifically for 'corporate-trans' service (RevOps Maturity Radar)
  const isCorporateTrans = service.id === 'corporate-trans';
  const [radarValues, setRadarValues] = useState<number[]>([2, 2, 2, 2, 2]); // Initial balanced low score
  const [interactedAxes, setInteractedAxes] = useState<Set<number>>(new Set());

  // Logic specifically for 'global-dominance' service (Econometric Attribution Lab)
  const isGlobalDominance = service.id === 'global-dominance';
  const [legacyBudget, setLegacyBudget] = useState(20); // Scale 0-100 (represents $0-1M)
  const [digitalBudget, setDigitalBudget] = useState(80); // Scale 0-100

  const [showWarning, setShowWarning] = useState(false);

  // --- LOGIC CALCULATORS ---

  // 1. Starter & Market Fit Logic
  let simpleChecksPassed = true;
  if (isStarter) {
    simpleChecksPassed = starterChecks.budget && starterChecks.admin && starterChecks.asyncReport;
  } else if (isMarketFit) {
    simpleChecksPassed = marketFitChecks.budget && marketFitChecks.traction && marketFitChecks.assets;
  }

  // 2. Business Scaling Logic (Scanner)
  const scalingResources = scalingNodes.capital && scalingNodes.human; 
  const scalingInfra = scalingNodes.tech && scalingNodes.data; 
  const scalingActiveCount = Object.values(scalingNodes).filter(Boolean).length;
  const scalingIntegrity = scalingActiveCount * 25;
  const scalingEnabled = isBusinessScaling && scalingResources; 

  // 3. Fractional Growth Logic (Neural Network)
  const fractionalActiveCount = Object.values(fractionalNodes).filter(Boolean).length;
  const fractionalEnabled = fractionalActiveCount >= 2; 
  let complexityLevel = "LOW";
  let complexityColor = "text-gray-500";
  if (fractionalActiveCount >= 2 && fractionalActiveCount < 4) {
    complexityLevel = "MED";
    complexityColor = "text-brand-accent";
  } else if (fractionalActiveCount === 4) {
    complexityLevel = "HIGH";
    complexityColor = "text-purple-400";
  }

  // 4. Corporate Transformation Logic (Radar)
  const radarAverage = radarValues.reduce((a, b) => a + b, 0) / NUM_AXES;
  const radarScorePercent = (radarAverage / MAX_VALUE) * 100;
  const isRadarReady = interactedAxes.size >= 3; // Enable button after touching 3 axes
  const isHighRisk = radarScorePercent < 50;
  const radarPath = radarValues.map((val, i) => {
    const point = getRadarPoint(i, val);
    return `${i === 0 ? 'M' : 'L'} ${point.x} ${point.y}`;
  }).join(' ') + ' Z';
  const radarLabels = ["Data Unif.", "Attribution", "Alignment", "AI Readiness", "Agility"];

  // 5. Global Dominance Logic (Econometric Lab)
  // Logic: High imbalance between legacy and digital causes 'saturation' (diminishing returns)
  const totalBudget = legacyBudget + digitalBudget;
  const maxChannel = Math.max(legacyBudget, digitalBudget);
  const imbalanceRatio = totalBudget > 0 ? maxChannel / totalBudget : 0.5;
  const isSaturated = imbalanceRatio > 0.7 && totalBudget > 50; // Saturated if >70% in one channel
  
  // Generate S-Curve points
  // Formula simulation: Y = (X * Efficiency) * SaturationCurve
  const curvePoints = useMemo(() => {
    const points = [];
    const width = 100; // SVG ViewBox width
    const height = 60; // SVG ViewBox height
    
    // As imbalance increases, efficiency decreases (plateau is lower and earlier)
    const efficiencyFactor = 1 - (Math.max(0, imbalanceRatio - 0.5) * 1.2); 
    
    for (let i = 0; i <= width; i+=2) {
       // Normalized X (0 to 1) relative to total budget capability
       // We map the current 'totalBudget' to the progress of the curve
       // But to show the 'shape', we plot a theoretical curve based on the current MIX
       
       const xNorm = i / width; 
       
       // Sigmoid-like function for Diminishing Returns
       // y = x / (x + k) where k determines slope
       // We modify k based on efficiency. Lower efficiency = faster saturation (flatter curve)
       
       const saturationPoint = 0.3 + (efficiencyFactor * 0.5); 
       // If efficient, sat point is high (0.8). If inefficient, sat point is low (0.3).
       
       let yNorm = xNorm / (xNorm + saturationPoint); // Standard Diminishing Return formula
       
       // Scale Y by efficiency magnitude
       yNorm = yNorm * (0.5 + (efficiencyFactor * 0.5));

       const x = i;
       const y = height - (yNorm * height * 1.2); // Invert Y for SVG and scale
       points.push(`${x},${Math.max(0, y)}`);
    }
    return points.join(' ');
  }, [imbalanceRatio]);
  


  // --- GLOBAL STATE RESOLUTION ---
  
  let isButtonEnabled = true;
  let warningMessage = "";
  let buttonText = service.category === ServiceCategory.ENTERPRISE ? 'Agendar Consultoría' : 'Aplicar ahora';
  
  if (isStarter) {
    isButtonEnabled = simpleChecksPassed;
    warningMessage = "Debes confirmar los requisitos operativos.";
  } else if (isMarketFit) {
    isButtonEnabled = simpleChecksPassed;
    warningMessage = "Requisitos de validación incompletos para este nivel.";
  } else if (isBusinessScaling) {
    isButtonEnabled = scalingEnabled;
    if (!scalingResources) {
      warningMessage = "ERROR: Recursos insuficientes para escalamiento.";
    } else if (scalingResources && !scalingInfra) {
      buttonText = "Solucionar Infraestructura"; 
    } else if (scalingResources && scalingInfra) {
      buttonText = "Iniciar Escalamiento";
    }
  } else if (isFractionalGrowth) {
    isButtonEnabled = fractionalEnabled;
    if (!fractionalEnabled) {
      warningMessage = "Configura al menos 2 agentes para continuar.";
      buttonText = "Configurar Ecosistema IA";
    } else {
      buttonText = "Solicitar Acceso al Protocolo";
    }
  } else if (isCorporateTrans) {
    isButtonEnabled = true;
    if (!isRadarReady) {
       buttonText = "Agendar Consultoría";
    } else {
       buttonText = isHighRisk ? "Diagnosticar Fugas de Capital" : "Iniciar Transformación AI";
    }
  } else if (isGlobalDominance) {
    isButtonEnabled = true;
    if (isSaturated) {
      buttonText = "Corregir Ineficiencia (Audit)";
    } else {
      buttonText = "Escalar Modelo Global";
    }
  }

  // --- HANDLERS ---

  const handleStarterCheck = (key: keyof typeof starterChecks) => {
    setStarterChecks(prev => ({ ...prev, [key]: !prev[key] }));
    if (showWarning) setShowWarning(false);
  };

  const handleMarketFitCheck = (key: keyof typeof marketFitChecks) => {
    setMarketFitChecks(prev => ({ ...prev, [key]: !prev[key] }));
    if (showWarning) setShowWarning(false);
  };

  const handleScalingNodeToggle = (key: keyof typeof scalingNodes) => {
    setScalingNodes(prev => ({ ...prev, [key]: !prev[key] }));
    if (showWarning) setShowWarning(false);
  }

  const handleFractionalNodeToggle = (key: keyof typeof fractionalNodes) => {
    setFractionalNodes(prev => ({ ...prev, [key]: !prev[key] }));
    if (showWarning) setShowWarning(false);
  }

  const handleRadarChange = (axisIndex: number, newValue: number) => {
    const newValues = [...radarValues];
    newValues[axisIndex] = newValue;
    setRadarValues(newValues);
    
    const newInteractions = new Set(interactedAxes);
    newInteractions.add(axisIndex);
    setInteractedAxes(newInteractions);
  };

  const handleDisabledClick = () => {
    if (!isButtonEnabled) {
      setShowWarning(true);
      setTimeout(() => setShowWarning(false), 3000);
    }
  };

  // --- DYNAMIC STYLES ---
  const getIntegrityColor = () => {
    if (scalingIntegrity < 50) return 'bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]';
    if (scalingIntegrity < 100) return 'bg-amber-400 shadow-[0_0_10px_rgba(251,191,36,0.5)]';
    return 'bg-brand-accent shadow-[0_0_10px_rgba(102,252,241,0.5)]';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className={`
        relative group rounded-2xl p-6 md:p-8 transition-all duration-300 flex flex-col h-full
        ${service.isPremium 
          ? 'bg-gradient-to-br from-gray-900 to-gray-800 border-0 shadow-2xl' 
          : 'bg-brand-gray/50 border border-white/5 hover:bg-brand-gray'}
        ${service.isPopular ? 'border-brand-accent/40 shadow-lg shadow-brand-accent/5' : ''}
      `}
    >
      {/* Premium Border Effect */}
      {service.isPremium && (
        <div className="absolute inset-0 rounded-2xl p-[1px] bg-gradient-to-r from-brand-accent via-blue-600 to-brand-accent opacity-50 group-hover:opacity-100 transition-opacity -z-10 animate-glow"></div>
      )}

      {/* Header Icon & Badges */}
      <div className="flex justify-between items-start mb-6">
        <div className={`p-3 rounded-lg ${service.isPremium ? 'bg-brand-accent text-brand-dark' : 'bg-white/5 text-brand-accent'}`}>
          <service.icon size={24} />
        </div>
        <div className="flex flex-col items-end gap-2">
          {service.isPremium && (
            <span className="px-3 py-1 text-[10px] md:text-xs font-bold text-brand-dark bg-brand-accent rounded-full uppercase tracking-wide">
              Prime Product
            </span>
          )}
          {service.isPopular && (
            <span className="px-3 py-1 text-[10px] md:text-xs font-bold text-brand-dark bg-brand-accent rounded-full uppercase tracking-wide">
              Most Popular
            </span>
          )}
        </div>
      </div>

      <h4 className="text-xl md:text-2xl font-bold text-white mb-4">{service.title}</h4>
      
      {/* Financial Breakdown Block */}
      <div className="mb-6 p-4 rounded-xl bg-black/30 border border-white/5 backdrop-blur-sm">
        <div className="flex justify-between items-end mb-2">
           <span className="text-[10px] md:text-xs text-gray-500 uppercase tracking-widest">Inversión Mensual</span>
           <span className="text-xl md:text-2xl font-mono font-bold text-white">{service.totalInvestment}</span>
        </div>
        <div className="w-full h-px bg-white/10 mb-2"></div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs font-mono mb-1 gap-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-brand-accent font-semibold">Fees: {service.fee}</span>
            <span className="text-gray-600">+</span>
            <span className="text-blue-400">Ads: {service.adSpend}</span>
          </div>
          <Calculator className="w-3 h-3 text-gray-600 hidden sm:block" />
        </div>

        {/* Setup Fee Addition */}
        {service.setupFee && (
          <div className="mt-3 pt-3 border-t border-dashed border-white/10">
            <div className="flex items-center gap-2 mb-1">
              <Bot className="w-3 h-3 text-purple-400" />
              <span className="text-[10px] text-purple-400 uppercase tracking-wider font-bold">Ingeniería IA (Setup)</span>
            </div>
            <div className="text-xs md:text-sm font-mono text-purple-200">
              {service.setupFee}
            </div>
          </div>
        )}
      </div>

      <p className="text-gray-400 mb-8 h-auto min-h-[48px] leading-relaxed text-sm">
        {service.description}
      </p>

      {/* Deliverables List */}
      <div className="space-y-3 mb-8 flex-grow">
        {service.deliverables.map((item, i) => (
          <div key={i} className="flex items-start gap-3">
            <Check className="w-4 h-4 text-brand-accent/50 shrink-0 mt-0.5" />
            <span className="text-sm text-gray-300">{item}</span>
          </div>
        ))}
      </div>

      {/* --- QUALIFICATION LOGIC FOR STARTER --- */}
      {isStarter && (
        <div className="mb-6 p-4 rounded-lg bg-red-500/5 border border-red-500/10">
          <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Requisitos Operativos</p>
          <div className="space-y-3">
            <button 
              onClick={() => handleStarterCheck('budget')}
              className="flex items-start gap-3 text-left w-full group/check"
            >
              <div className={`mt-0.5 shrink-0 transition-colors ${starterChecks.budget ? 'text-brand-accent' : 'text-gray-600 group-hover/check:text-gray-400'}`}>
                {starterChecks.budget ? <CheckSquare size={18} /> : <Square size={18} />}
              </div>
              <span className={`text-xs leading-tight transition-colors ${starterChecks.budget ? 'text-gray-200' : 'text-gray-500'}`}>
                Cuento con un presupuesto <strong className="text-white">ADICIONAL de $250</strong> para pagar a Facebook.
              </span>
            </button>
            <button 
              onClick={() => handleStarterCheck('admin')}
              className="flex items-start gap-3 text-left w-full group/check"
            >
              <div className={`mt-0.5 shrink-0 transition-colors ${starterChecks.admin ? 'text-brand-accent' : 'text-gray-600 group-hover/check:text-gray-400'}`}>
                {starterChecks.admin ? <CheckSquare size={18} /> : <Square size={18} />}
              </div>
              <span className={`text-xs leading-tight transition-colors ${starterChecks.admin ? 'text-gray-200' : 'text-gray-500'}`}>
                Tengo acceso administrador a mi Fanpage e Instagram.
              </span>
            </button>
            <button 
              onClick={() => handleStarterCheck('asyncReport')}
              className="flex items-start gap-3 text-left w-full group/check"
            >
              <div className={`mt-0.5 shrink-0 transition-colors ${starterChecks.asyncReport ? 'text-brand-accent' : 'text-gray-600 group-hover/check:text-gray-400'}`}>
                {starterChecks.asyncReport ? <CheckSquare size={18} /> : <Square size={18} />}
              </div>
              <span className={`text-xs leading-tight transition-colors ${starterChecks.asyncReport ? 'text-gray-200' : 'text-gray-500'}`}>
                Entiendo que este plan <strong className="text-white">no incluye reuniones</strong>, solo reportes en video.
              </span>
            </button>
          </div>
        </div>
      )}

      {/* --- QUALIFICATION LOGIC FOR MARKET FIT --- */}
      {isMarketFit && (
        <div className="mb-6 p-4 rounded-lg bg-red-500/5 border border-red-500/10">
          <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Validación de Escalamiento</p>
          <div className="space-y-3">
            <button 
              onClick={() => handleMarketFitCheck('budget')}
              className="flex items-start gap-3 text-left w-full group/check"
            >
              <div className={`mt-0.5 shrink-0 transition-colors ${marketFitChecks.budget ? 'text-brand-accent' : 'text-gray-600 group-hover/check:text-gray-400'}`}>
                {marketFitChecks.budget ? <CheckSquare size={18} /> : <Square size={18} />}
              </div>
              <span className={`text-xs leading-tight transition-colors ${marketFitChecks.budget ? 'text-gray-200' : 'text-gray-500'}`}>
                Confirmo presupuesto de pauta de <strong className="text-white">$600 USD</strong> (adicional a honorarios).
              </span>
            </button>
            <button 
              onClick={() => handleMarketFitCheck('traction')}
              className="flex items-start gap-3 text-left w-full group/check"
            >
              <div className={`mt-0.5 shrink-0 transition-colors ${marketFitChecks.traction ? 'text-brand-accent' : 'text-gray-600 group-hover/check:text-gray-400'}`}>
                {marketFitChecks.traction ? <CheckSquare size={18} /> : <Square size={18} />}
              </div>
              <span className={`text-xs leading-tight transition-colors ${marketFitChecks.traction ? 'text-gray-200' : 'text-gray-500'}`}>
                Mi negocio ya tiene ventas validadas y busco escalar canales.
              </span>
            </button>
            <button 
              onClick={() => handleMarketFitCheck('assets')}
              className="flex items-start gap-3 text-left w-full group/check"
            >
              <div className={`mt-0.5 shrink-0 transition-colors ${marketFitChecks.assets ? 'text-brand-accent' : 'text-gray-600 group-hover/check:text-gray-400'}`}>
                {marketFitChecks.assets ? <CheckSquare size={18} /> : <Square size={18} />}
              </div>
              <span className={`text-xs leading-tight transition-colors ${marketFitChecks.assets ? 'text-gray-200' : 'text-gray-500'}`}>
                Dispongo de activos para Google Ads (Web/Landing) o presupuesto para crearlos.
              </span>
            </button>
          </div>
        </div>
      )}

      {/* --- THE INFRASTRUCTURE SCANNER (Business Scaling) --- */}
      {isBusinessScaling && (
        <div className="mb-6 bg-black/40 border border-white/10 rounded-lg overflow-hidden backdrop-blur-sm">
          {/* Scanner Header */}
          <div className="bg-black/60 px-4 py-2 border-b border-white/10 flex items-center justify-between">
            <span className="text-[10px] font-mono text-emerald-500 animate-pulse flex items-center gap-1">
              <ScanLine size={12} />
              {'>'} SYSTEM DIAGNOSTIC_
            </span>
            <Activity size={12} className="text-gray-500" />
          </div>

          <div className="p-4">
            {/* 4-Node Grid */}
            <div className="grid grid-cols-2 gap-3 mb-4">
               {/* Node 1: Capital */}
               <button 
                  onClick={() => handleScalingNodeToggle('capital')}
                  className={`p-3 rounded border transition-all duration-300 flex flex-col items-center gap-2 group/node ${scalingNodes.capital 
                    ? 'bg-cyan-950/30 border-cyan-500/50 shadow-[0_0_15px_rgba(34,211,238,0.15)]' 
                    : 'bg-white/5 border-white/5 hover:bg-white/10'}`}
               >
                  <CircleDollarSign size={20} className={`transition-colors ${scalingNodes.capital ? 'text-cyan-400 drop-shadow-[0_0_5px_rgba(34,211,238,0.8)]' : 'text-gray-600'}`} />
                  <span className={`text-[10px] font-mono uppercase ${scalingNodes.capital ? 'text-cyan-300' : 'text-gray-500'}`}>Ads {'>'} $1.5k</span>
               </button>

               {/* Node 2: Human */}
               <button 
                  onClick={() => handleScalingNodeToggle('human')}
                  className={`p-3 rounded border transition-all duration-300 flex flex-col items-center gap-2 group/node ${scalingNodes.human
                    ? 'bg-cyan-950/30 border-cyan-500/50 shadow-[0_0_15px_rgba(34,211,238,0.15)]' 
                    : 'bg-white/5 border-white/5 hover:bg-white/10'}`}
               >
                  <Users size={20} className={`transition-colors ${scalingNodes.human ? 'text-cyan-400 drop-shadow-[0_0_5px_rgba(34,211,238,0.8)]' : 'text-gray-600'}`} />
                  <span className={`text-[10px] font-mono uppercase ${scalingNodes.human ? 'text-cyan-300' : 'text-gray-500'}`}>Equipo Ventas</span>
               </button>

               {/* Node 3: Tech */}
               <button 
                  onClick={() => handleScalingNodeToggle('tech')}
                  className={`p-3 rounded border transition-all duration-300 flex flex-col items-center gap-2 group/node ${scalingNodes.tech
                    ? 'bg-cyan-950/30 border-cyan-500/50 shadow-[0_0_15px_rgba(34,211,238,0.15)]' 
                    : 'bg-white/5 border-white/5 hover:bg-white/10'}`}
               >
                  <Database size={20} className={`transition-colors ${scalingNodes.tech ? 'text-cyan-400 drop-shadow-[0_0_5px_rgba(34,211,238,0.8)]' : 'text-gray-600'}`} />
                  <span className={`text-[10px] font-mono uppercase ${scalingNodes.tech ? 'text-cyan-300' : 'text-gray-500'}`}>CRM Activo</span>
               </button>

               {/* Node 4: Data */}
               <button 
                  onClick={() => handleScalingNodeToggle('data')}
                  className={`p-3 rounded border transition-all duration-300 flex flex-col items-center gap-2 group/node ${scalingNodes.data
                    ? 'bg-cyan-950/30 border-cyan-500/50 shadow-[0_0_15px_rgba(34,211,238,0.15)]' 
                    : 'bg-white/5 border-white/5 hover:bg-white/10'}`}
               >
                  <BarChart3 size={20} className={`transition-colors ${scalingNodes.data ? 'text-cyan-400 drop-shadow-[0_0_5px_rgba(34,211,238,0.8)]' : 'text-gray-600'}`} />
                  <span className={`text-[10px] font-mono uppercase ${scalingNodes.data ? 'text-cyan-300' : 'text-gray-500'}`}>Data Histórica</span>
               </button>
            </div>

            {/* Integrity Bar */}
            <div className="mb-3">
              <div className="flex justify-between text-[10px] uppercase font-mono text-gray-500 mb-1">
                <span>System Integrity</span>
                <span className={scalingIntegrity < 100 ? (scalingIntegrity < 50 ? 'text-red-500' : 'text-amber-400') : 'text-brand-accent'}>{scalingIntegrity}%</span>
              </div>
              <div className="h-1.5 bg-gray-800 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${scalingIntegrity}%` }}
                  className={`h-full transition-all duration-500 ${getIntegrityColor()}`}
                />
              </div>
            </div>

            {/* Diagnostic Message */}
            <div className="min-h-[20px]">
              <AnimatePresence mode="wait">
                {scalingIntegrity === 0 && (
                   <motion.p initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="text-[10px] font-mono text-gray-500 text-center animate-pulse">
                     ESPERANDO INPUT...
                   </motion.p>
                )}
                {scalingIntegrity > 0 && !scalingResources && (
                  <motion.p initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="text-[10px] font-mono text-red-400 text-center font-bold">
                    ERROR: Recursos insuficientes para escalamiento.
                  </motion.p>
                )}
                {scalingResources && !scalingInfra && (
                   <motion.p initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="text-[10px] font-mono text-amber-400 text-center font-bold">
                    ALERTA: Fuga de leads detectada. Se requiere CRM.
                   </motion.p>
                )}
                {scalingIntegrity === 100 && (
                   <motion.p initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="text-[10px] font-mono text-brand-accent text-center font-bold">
                    SISTEMA LISTO: Condiciones ideales para aceleración.
                   </motion.p>
                )}
              </AnimatePresence>
            </div>

          </div>
        </div>
      )}

      {/* --- THE NEURAL NETWORK BUILDER (Fractional Growth) --- */}
      {isFractionalGrowth && (
        <>
          <div className="mb-3 flex items-start gap-2 px-1">
             <MousePointerClick className="w-4 h-4 text-purple-400 mt-0.5 shrink-0 animate-bounce" />
             <p className="text-xs text-gray-400 leading-relaxed font-mono">
               <span className="text-white font-bold">Simulación de Arquitectura:</span> Haz clic en los nodos satélite para conectarlos al núcleo central. Activa <span className="text-purple-400">mínimo 2 agentes</span> para validar el sistema.
             </p>
          </div>
          <div className="mb-6 relative h-[250px] bg-black/60 rounded-xl border border-purple-500/20 overflow-hidden group/network">
             {/* Grid Background */}
             <div className="absolute inset-0 bg-[linear-gradient(to_right,#4f46e51a_1px,transparent_1px),linear-gradient(to_bottom,#4f46e51a_1px,transparent_1px)] bg-[size:16px_16px] [mask-image:radial-gradient(ellipse_60%_60%_at_50%_50%,#000_70%,transparent_100%)]"></div>
  
             {/* SVG Connections Layer (Z-0) */}
             <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
               {/* Line to Sales (Top Left) */}
               <motion.line 
                  x1="20%" y1="25%" x2="50%" y2="50%" 
                  stroke="#a855f7" strokeWidth="1.5" strokeDasharray="4 2"
                  initial={{ pathLength: 0, opacity: 0.2 }}
                  animate={{ pathLength: fractionalNodes.sales ? 1 : 0, opacity: fractionalNodes.sales ? 1 : 0.2 }}
                  transition={{ duration: 0.5 }}
               />
               {/* Line to BI (Top Right) */}
               <motion.line 
                  x1="80%" y1="25%" x2="50%" y2="50%" 
                  stroke="#a855f7" strokeWidth="1.5" strokeDasharray="4 2"
                  initial={{ pathLength: 0, opacity: 0.2 }}
                  animate={{ pathLength: fractionalNodes.bi ? 1 : 0, opacity: fractionalNodes.bi ? 1 : 0.2 }}
                  transition={{ duration: 0.5 }}
               />
               {/* Line to Support (Bottom Left) */}
               <motion.line 
                  x1="25%" y1="75%" x2="50%" y2="50%" 
                  stroke="#a855f7" strokeWidth="1.5" strokeDasharray="4 2"
                  initial={{ pathLength: 0, opacity: 0.2 }}
                  animate={{ pathLength: fractionalNodes.support ? 1 : 0, opacity: fractionalNodes.support ? 1 : 0.2 }}
                  transition={{ duration: 0.5 }}
               />
               {/* Line to Email (Bottom Right) */}
               <motion.line 
                  x1="75%" y1="75%" x2="50%" y2="50%" 
                  stroke="#a855f7" strokeWidth="1.5" strokeDasharray="4 2"
                  initial={{ pathLength: 0, opacity: 0.2 }}
                  animate={{ pathLength: fractionalNodes.email ? 1 : 0, opacity: fractionalNodes.email ? 1 : 0.2 }}
                  transition={{ duration: 0.5 }}
               />
             </svg>
  
             {/* Nodes Layer (Z-10) */}
             
             {/* Core Node */}
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center gap-1 z-10">
                <div className="relative">
                   <div className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-md border border-white/40 flex items-center justify-center shadow-[0_0_20px_rgba(255,255,255,0.2)] animate-pulse">
                      <Cpu className="w-5 h-5 text-white" />
                   </div>
                   {/* Core glow */}
                   <div className="absolute inset-0 bg-white/20 rounded-full blur-md -z-10 animate-ping"></div>
                </div>
                <span className="text-[9px] font-mono text-white/80 tracking-widest bg-black/50 px-1 rounded">CORE DATA</span>
             </div>
  
             {/* Agent 1: Sales (Top Left) */}
             <button 
               onClick={() => handleFractionalNodeToggle('sales')}
               className="absolute top-[25%] left-[20%] -translate-x-1/2 -translate-y-1/2 flex flex-col items-center gap-1 group/node z-10 transition-transform active:scale-95"
             >
                <div className={`w-8 h-8 rounded-full border flex items-center justify-center transition-all duration-300 ${fractionalNodes.sales ? 'bg-purple-500/20 border-purple-400 shadow-[0_0_15px_rgba(168,85,247,0.5)]' : 'bg-black/40 border-gray-700 hover:border-gray-500'}`}>
                   <Bot className={`w-4 h-4 transition-colors ${fractionalNodes.sales ? 'text-purple-300' : 'text-gray-600'}`} />
                </div>
                <span className={`text-[8px] font-mono uppercase transition-colors ${fractionalNodes.sales ? 'text-purple-300' : 'text-gray-600'}`}>Sales Agent</span>
             </button>
  
             {/* Agent 2: BI (Top Right) */}
             <button 
               onClick={() => handleFractionalNodeToggle('bi')}
               className="absolute top-[25%] left-[80%] -translate-x-1/2 -translate-y-1/2 flex flex-col items-center gap-1 group/node z-10 transition-transform active:scale-95"
             >
                <div className={`w-8 h-8 rounded-full border flex items-center justify-center transition-all duration-300 ${fractionalNodes.bi ? 'bg-purple-500/20 border-purple-400 shadow-[0_0_15px_rgba(168,85,247,0.5)]' : 'bg-black/40 border-gray-700 hover:border-gray-500'}`}>
                   <LineChart className={`w-4 h-4 transition-colors ${fractionalNodes.bi ? 'text-purple-300' : 'text-gray-600'}`} />
                </div>
                <span className={`text-[8px] font-mono uppercase transition-colors ${fractionalNodes.bi ? 'text-purple-300' : 'text-gray-600'}`}>Predictive BI</span>
             </button>
  
             {/* Agent 3: Support (Bottom Left) */}
             <button 
               onClick={() => handleFractionalNodeToggle('support')}
               className="absolute top-[75%] left-[25%] -translate-x-1/2 -translate-y-1/2 flex flex-col items-center gap-1 group/node z-10 transition-transform active:scale-95"
             >
                <div className={`w-8 h-8 rounded-full border flex items-center justify-center transition-all duration-300 ${fractionalNodes.support ? 'bg-purple-500/20 border-purple-400 shadow-[0_0_15px_rgba(168,85,247,0.5)]' : 'bg-black/40 border-gray-700 hover:border-gray-500'}`}>
                   <MessageSquare className={`w-4 h-4 transition-colors ${fractionalNodes.support ? 'text-purple-300' : 'text-gray-600'}`} />
                </div>
                <span className={`text-[8px] font-mono uppercase transition-colors ${fractionalNodes.support ? 'text-purple-300' : 'text-gray-600'}`}>Support Bot</span>
             </button>
  
             {/* Agent 4: Email (Bottom Right) */}
             <button 
               onClick={() => handleFractionalNodeToggle('email')}
               className="absolute top-[75%] left-[75%] -translate-x-1/2 -translate-y-1/2 flex flex-col items-center gap-1 group/node z-10 transition-transform active:scale-95"
             >
                <div className={`w-8 h-8 rounded-full border flex items-center justify-center transition-all duration-300 ${fractionalNodes.email ? 'bg-purple-500/20 border-purple-400 shadow-[0_0_15px_rgba(168,85,247,0.5)]' : 'bg-black/40 border-gray-700 hover:border-gray-500'}`}>
                   <Mail className={`w-4 h-4 transition-colors ${fractionalNodes.email ? 'text-purple-300' : 'text-gray-600'}`} />
                </div>
                <span className={`text-[8px] font-mono uppercase transition-colors ${fractionalNodes.email ? 'text-purple-300' : 'text-gray-600'}`}>Auto-Emailer</span>
             </button>
  
             {/* Complexity Indicator */}
             <div className="absolute bottom-2 left-0 right-0 text-center">
                <span className="text-[9px] font-mono text-gray-500 mr-2">{'>'} SYSTEM COMPLEXITY:</span>
                <span className={`text-[9px] font-mono font-bold ${complexityColor}`}>{complexityLevel}</span>
             </div>
          </div>
        </>
      )}

      {/* --- REVOPS MATURITY RADAR (Corporate Transformation) --- */}
      {isCorporateTrans && (
        <div className="mb-6 bg-black/50 rounded-xl border border-white/10 overflow-hidden backdrop-blur-sm">
          {/* Header */}
          <div className="flex items-center justify-between p-3 border-b border-white/10 bg-white/5">
            <div className="flex items-center gap-2">
              <Radar className="w-4 h-4 text-brand-accent" />
              <span className="text-xs font-bold text-gray-300 tracking-wide">REVOPS MATURITY RADAR</span>
            </div>
            <span className="text-[10px] font-mono text-gray-500">INTERACTIVE</span>
          </div>

          <div className="p-4 flex flex-col items-center">
            {/* Radar Chart SVG */}
            <div className="relative w-[220px] h-[220px]">
              <svg viewBox={`0 0 ${CENTER * 2} ${CENTER * 2}`} className="w-full h-full overflow-visible">
                {/* Background Grid (Concentric Pentagons) */}
                {[1, 2, 3, 4, 5].map((level) => (
                  <polygon
                    key={`grid-${level}`}
                    points={Array.from({ length: NUM_AXES }).map((_, i) => {
                      const point = getRadarPoint(i, level);
                      return `${point.x},${point.y}`;
                    }).join(' ')}
                    className="fill-none stroke-white/5"
                    strokeWidth="1"
                  />
                ))}

                {/* Axis Lines */}
                {Array.from({ length: NUM_AXES }).map((_, i) => {
                  const endPoint = getRadarPoint(i, MAX_VALUE);
                  return (
                    <line
                      key={`axis-${i}`}
                      x1={CENTER} y1={CENTER}
                      x2={endPoint.x} y2={endPoint.y}
                      className="stroke-white/10"
                      strokeWidth="1"
                    />
                  );
                })}

                {/* Animated Data Polygon */}
                <motion.path
                  d={radarPath}
                  className="fill-brand-accent/20 stroke-brand-accent"
                  strokeWidth="2"
                  initial={false}
                  animate={{ d: radarPath }}
                  transition={{ type: "spring", stiffness: 300, damping: 25 }}
                />

                {/* Interactive Points on Axes */}
                {Array.from({ length: NUM_AXES }).map((_, axisIdx) => (
                  <g key={`interactive-axis-${axisIdx}`}>
                    {/* Render invisible click targets for better UX */}
                     {[1, 2, 3, 4, 5].map((level) => {
                        const point = getRadarPoint(axisIdx, level);
                        const isSelected = radarValues[axisIdx] === level;
                        return (
                          <circle
                             key={`point-${axisIdx}-${level}`}
                             cx={point.x} cy={point.y}
                             r={isSelected ? 3 : 2}
                             className={`
                                cursor-pointer transition-all duration-200 
                                ${isSelected ? 'fill-white stroke-brand-accent stroke-2' : 'fill-gray-700 hover:fill-brand-accent/50'}
                             `}
                             onClick={() => handleRadarChange(axisIdx, level)}
                          />
                        );
                     })}
                  </g>
                ))}

                {/* Labels */}
                {radarLabels.map((label, i) => {
                  const point = getRadarPoint(i, MAX_VALUE + 1.2); // Position slightly outside
                  // Adjust anchor based on position
                  let anchor = "middle";
                  let baseline = "middle";
                  if (i === 1 || i === 2) anchor = "start";
                  if (i === 3 || i === 4) anchor = "end";
                  if (i === 0) baseline = "auto"; // Top label

                  return (
                    <text
                      key={`label-${i}`}
                      x={point.x} y={point.y}
                      textAnchor={anchor}
                      dominantBaseline={baseline}
                      className="fill-gray-400 text-[8px] font-mono uppercase"
                    >
                      {label}
                    </text>
                  );
                })}
              </svg>
            </div>
            
            {/* Status Message */}
            <div className="mt-4 w-full bg-black/40 p-2 rounded border border-white/5 text-center">
              {isHighRisk ? (
                <div className="flex items-center justify-center gap-2 text-amber-500">
                  <AlertTriangle className="w-3 h-3" />
                  <span className="text-[10px] font-mono font-bold">STATUS: FRAGMENTED OPERATIONS. HIGH RISK.</span>
                </div>
              ) : (
                <div className="flex items-center justify-center gap-2 text-emerald-400">
                  <CheckCircle2 className="w-3 h-3" />
                  <span className="text-[10px] font-mono font-bold">STATUS: SCALABLE ARCHITECTURE. AI READY.</span>
                </div>
              )}
              <div className="mt-1 flex justify-between px-4 text-[9px] text-gray-500 font-mono">
                 <span>MATURITY: {Math.round(radarScorePercent)}%</span>
                 <span>AXES CHECKED: {interactedAxes.size}/{NUM_AXES}</span>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* --- ECONOMETRIC ATTRIBUTION LAB (Global Dominance) --- */}
      {isGlobalDominance && (
        <div className="mb-6 bg-black rounded-lg border border-white/10 overflow-hidden shadow-2xl">
           {/* Terminal Header */}
           <div className="flex items-center justify-between p-2 border-b border-white/10 bg-white/5">
              <div className="flex items-center gap-2 text-[10px] font-mono text-gray-400">
                 <Globe className="w-3 h-3" />
                 <span>ECONOMETRIC LAB v4.0</span>
              </div>
              <span className="text-[10px] font-mono text-brand-accent animate-pulse">LIVE FEED</span>
           </div>

           <div className="p-4 space-y-4">
              {/* Sliders Input */}
              <div className="space-y-4">
                 <div>
                    <div className="flex justify-between text-[10px] font-mono mb-1 text-gray-400">
                       <span>LEGACY MEDIA (TV/OOH)</span>
                       <span className="text-white">${legacyBudget * 10}k</span>
                    </div>
                    <input 
                      type="range" min="0" max="100" value={legacyBudget} 
                      onChange={(e) => setLegacyBudget(Number(e.target.value))}
                      className="w-full h-1 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-brand-accent hover:accent-white transition-all"
                    />
                 </div>
                 <div>
                    <div className="flex justify-between text-[10px] font-mono mb-1 text-gray-400">
                       <span>DIGITAL PERFORMANCE</span>
                       <span className="text-white">${digitalBudget * 10}k</span>
                    </div>
                    <input 
                      type="range" min="0" max="100" value={digitalBudget} 
                      onChange={(e) => setDigitalBudget(Number(e.target.value))}
                      className="w-full h-1 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-brand-accent hover:accent-white transition-all"
                    />
                 </div>
              </div>

              {/* S-Curve Chart */}
              <div className="h-[150px] w-full border border-white/10 bg-black relative">
                  {/* Grid Lines */}
                  <div className="absolute inset-0 grid grid-cols-4 grid-rows-4 pointer-events-none">
                     <div className="border-r border-b border-white/5"></div>
                     <div className="border-r border-b border-white/5"></div>
                     <div className="border-r border-b border-white/5"></div>
                     <div className="border-b border-white/5"></div>
                     <div className="border-r border-b border-white/5"></div>
                     <div className="border-r border-b border-white/5"></div>
                     <div className="border-r border-b border-white/5"></div>
                     <div className="border-b border-white/5"></div>
                     <div className="border-r border-white/5"></div>
                     <div className="border-r border-white/5"></div>
                     <div className="border-r border-white/5"></div>
                  </div>

                  <svg className="w-full h-full" viewBox="0 0 100 60" preserveAspectRatio="none">
                     <motion.path 
                        d={`M 0 60 L ${curvePoints}`}
                        fill="none"
                        stroke={isSaturated ? "#f59e0b" : "#66FCF1"}
                        strokeWidth="1.5"
                        initial={false}
                        animate={{ d: `M 0 60 L ${curvePoints}` }}
                        transition={{ type: "spring", stiffness: 200, damping: 20 }}
                     />
                     {/* Area under curve gradient */}
                     <motion.path 
                        d={`M 0 60 L ${curvePoints} L 100 60 Z`}
                        fill={isSaturated ? "rgba(245, 158, 11, 0.1)" : "rgba(102, 252, 241, 0.1)"}
                        stroke="none"
                        initial={false}
                        animate={{ d: `M 0 60 L ${curvePoints} L 100 60 Z` }}
                     />
                  </svg>
                  
                  {/* Axis Labels */}
                  <span className="absolute bottom-1 left-1 text-[8px] font-mono text-gray-600">INV: $0</span>
                  <span className="absolute bottom-1 right-1 text-[8px] font-mono text-gray-600">INV: MAX</span>
                  <span className="absolute top-1 left-1 text-[8px] font-mono text-gray-600">REV</span>
              </div>

              {/* Status Message */}
              <div className="flex items-center gap-2 p-2 rounded bg-white/5 border border-white/5">
                 {isSaturated ? (
                    <>
                       <AlertTriangle className="w-4 h-4 text-amber-500" />
                       <span className="text-[10px] font-mono text-amber-500 font-bold">
                          ⚠ ALERT: Channel Saturation Detected. ROAS Decreasing.
                       </span>
                    </>
                 ) : (
                    <>
                       <TrendingUp className="w-4 h-4 text-emerald-500" />
                       <span className="text-[10px] font-mono text-emerald-500 font-bold">
                          ✅ MODEL OPTIMIZED: MMM Efficiency Peak.
                       </span>
                    </>
                 )}
              </div>
           </div>
        </div>
      )}


      {/* CTA Button Wrapper to handle disabled clicks */}
      <div 
        className="mt-auto relative"
        onMouseEnter={() => !isButtonEnabled && setShowWarning(true)}
        onMouseLeave={() => setShowWarning(false)}
        onClickCapture={handleDisabledClick} // Catch clicks on the disabled button wrapper
      >
        <a 
          href={isButtonEnabled ? (service.bookingUrl || "#contact") : undefined}
          target={isButtonEnabled && service.bookingUrl ? "_blank" : "_self"}
          rel={isButtonEnabled && service.bookingUrl ? "noopener noreferrer" : ""}
          className={`
            w-full py-3 rounded-lg font-semibold flex items-center justify-center gap-2 transition-all
            ${!isButtonEnabled 
              ? 'bg-gray-800 text-gray-500 cursor-not-allowed opacity-50' 
              : service.isPremium 
                ? 'bg-brand-accent text-brand-dark hover:bg-white active:scale-95 cursor-pointer shadow-[0_0_15px_rgba(102,252,241,0.4)]'
                : isCorporateTrans && isRadarReady // Special styling for radar enabled
                    ? isHighRisk ? 'bg-amber-500 text-black hover:bg-amber-400' : 'bg-emerald-500 text-black hover:bg-emerald-400'
                    : isCorporateTrans && !isRadarReady // Special styling for radar disabled
                        ? 'bg-white/5 text-gray-400 hover:bg-white/10'
                        : isGlobalDominance // Special styling for Global Dominance
                            ? isSaturated 
                                ? 'bg-amber-500 text-black hover:bg-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.4)]' 
                                : 'bg-brand-accent text-brand-dark hover:bg-white shadow-[0_0_15px_rgba(102,252,241,0.4)]'
                            : 'bg-white/5 text-white hover:bg-white/10 active:scale-95 cursor-pointer'
            }
          `}
          // Prevent default link action if not checked (backup to href=undefined)
          onClick={(e) => !isButtonEnabled && e.preventDefault()}
        >
          {isFractionalGrowth && isButtonEnabled ? (
            <Zap className="w-4 h-4 fill-brand-dark" />
          ) : null}
          {buttonText} 
          {!isFractionalGrowth && <ArrowUpRight className="w-4 h-4" />}
        </a>

        {/* Warning Message */}
        <AnimatePresence>
          {(isStarter || isMarketFit || isBusinessScaling || isFractionalGrowth) && showWarning && !isButtonEnabled && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 5 }}
              exit={{ opacity: 0 }}
              className="absolute left-0 right-0 -bottom-10 text-center z-10"
            >
              <div className="flex items-center justify-center gap-1.5 text-[11px] leading-tight text-rose-500 font-medium bg-rose-500/10 py-1.5 px-3 rounded border border-rose-500/20 backdrop-blur-sm mx-auto w-fit shadow-lg">
                <AlertCircle className="w-3 h-3 shrink-0" />
                {warningMessage}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};


// --- Main Component ---
const Services: React.FC = () => {
  // State for the Micro-Offer dropdown
  const [isMicroOfferOpen, setIsMicroOfferOpen] = useState(false);

  // Group services by category for structure
  const categories = Object.values(ServiceCategory);

  return (
    <section id="services" className="py-20 md:py-24 bg-brand-dark relative overflow-hidden scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 leading-tight">Arquitectura de <br className="sm:hidden"/> Servicios Escalonada</h2>
          <p className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto px-2">
            Arquitectura de soluciones escalable. Desde la validación inicial hasta el dominio global del mercado.
          </p>
        </div>

        {categories.map((category) => (
          <div key={category} className="mb-16 last:mb-0">
            <h3 className="text-base md:text-lg font-mono text-brand-accent mb-6 flex items-center gap-2 after:h-px after:flex-1 after:bg-white/10 after:ml-4">
              {category}
            </h3>

            {/* Micro-Offer Dropdown for Validation Category */}
            {category === ServiceCategory.VALIDATION && (
              <div className="mb-8 max-w-4xl mx-auto">
                <button
                  onClick={() => setIsMicroOfferOpen(!isMicroOfferOpen)}
                  className="w-full relative group overflow-hidden bg-white/5 hover:bg-white/10 border border-amber-500/30 rounded-xl p-4 transition-all duration-300 flex items-center justify-between active:scale-[0.99]"
                >
                   {/* Background Glow Effect */}
                   <div className="absolute inset-0 bg-gradient-to-r from-amber-500/5 via-transparent to-amber-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                   <div className="flex items-center gap-3 relative z-10">
                      <div className="p-2 bg-amber-500/10 rounded-lg border border-amber-500/20">
                        <Sparkles className="w-5 h-5 text-amber-400" />
                      </div>
                      <span className="text-base md:text-lg font-bold bg-gradient-to-r from-amber-200 via-yellow-400 to-amber-200 bg-clip-text text-transparent text-left">
                        ¿Eres Emprendedor?
                      </span>
                   </div>
                   
                   <motion.div
                      animate={{ rotate: isMicroOfferOpen ? 180 : 0 }}
                      transition={{ duration: 0.3 }}
                      className="text-amber-200/50 group-hover:text-amber-200"
                   >
                     <ChevronDown className="w-6 h-6" />
                   </motion.div>
                </button>

                <AnimatePresence>
                  {isMicroOfferOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: "easeInOut" }}
                      className="overflow-hidden"
                    >
                      <div className="mt-2 p-4 md:p-6 rounded-xl bg-black/40 border border-white/5 flex flex-col md:flex-row gap-6 items-center md:items-start">
                         <div className="flex-1">
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-2 gap-2">
                               <h4 className="text-lg md:text-xl font-bold text-white">Consultoría Estratégica Express</h4>
                               <span className="flex items-center gap-1 text-xs font-mono text-amber-400 bg-amber-500/10 px-2 py-1 rounded border border-amber-500/20 w-fit">
                                  <Clock className="w-3 h-3" /> 1 Hora
                               </span>
                            </div>
                            <p className="text-gray-400 text-sm leading-relaxed mb-4">
                              Sesión intensiva de 60 minutos para resolver dudas puntuales sobre tus campañas o revisar tu estrategia. 
                              Sin ataduras mensuales.
                            </p>
                            <div className="flex flex-col sm:flex-row sm:items-center gap-2 text-sm text-gray-500">
                               <div className="flex items-center gap-2"><Check className="w-4 h-4 text-green-500" /> Auditoría rápida</div>
                               <span className="hidden sm:inline mx-2">•</span>
                               <div className="flex items-center gap-2"><Check className="w-4 h-4 text-green-500" /> Q&A Técnico</div>
                               <span className="hidden sm:inline mx-2">•</span>
                               <div className="flex items-center gap-2"><Check className="w-4 h-4 text-green-500" /> Grabación incluida</div>
                            </div>
                         </div>
                         
                         <div className="flex flex-col items-center gap-3 w-full md:w-auto min-w-[200px] mt-2 md:mt-0">
                            <div className="text-center">
                               <span className="text-3xl font-bold text-white block">$50 <span className="text-sm font-normal text-gray-500">USD</span></span>
                            </div>
                            <a 
                              href="https://wa.me/593962610510?text=Hola,%20me%20interesa%20la%20Consultor%C3%ADa%20Express%20de%201%20Hora."
                              target="_blank"
                              rel="noopener noreferrer"
                              className="w-full py-3 px-4 bg-white text-brand-dark font-bold rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center gap-2 active:scale-95"
                            >
                               Reservar Hora <ArrowUpRight className="w-4 h-4" />
                            </a>
                         </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
              {SERVICES.filter(s => s.category === category).map((service, index) => (
                <ServiceCard key={service.id} service={service} index={index} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Services;