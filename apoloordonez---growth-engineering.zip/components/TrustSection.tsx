import React from 'react';
import { motion } from 'framer-motion';
import { EXPERIENCE, CERTIFICATIONS } from '../constants';
import { Building, Award, CheckCircle2, ExternalLink } from 'lucide-react';

const TrustSection: React.FC = () => {
  return (
    <section id="expertise" className="py-24 bg-brand-gray relative scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Autoridad & Respaldo</h2>
          <div className="w-20 h-1 bg-brand-accent mb-6"></div>
          <p className="text-gray-400 max-w-3xl">
            Una carrera forjada en la intersección de tecnología, datos y estrategia de negocios. 
            Sin trucos, solo ingeniería de crecimiento aplicada en entornos de alta exigencia.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Experience Column */}
          <div>
            <div className="flex items-center gap-3 mb-8">
              <Building className="text-brand-accent w-6 h-6" />
              <h3 className="text-xl font-semibold text-white">Trayectoria Corporativa</h3>
            </div>
            <div className="space-y-8 border-l border-white/10 ml-3 pl-8 relative">
              {EXPERIENCE.map((job, idx) => (
                <motion.div 
                  key={job.id}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  viewport={{ once: true }}
                  className="relative"
                >
                  <span className="absolute -left-[41px] top-1 w-5 h-5 rounded-full bg-brand-dark border-2 border-brand-accent"></span>
                  <div className="mb-1 flex items-center justify-between">
                    <h4 className="text-lg font-bold text-white">{job.company}</h4>
                    <span className="text-xs font-mono text-brand-accent bg-brand-accent/10 px-2 py-1 rounded">
                      {job.year}
                    </span>
                  </div>
                  <div className="text-sm font-semibold text-gray-300 mb-2">{job.role}</div>
                  <p className="text-gray-400 text-sm leading-relaxed">{job.description}</p>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Certifications Column */}
          <div>
            <div className="flex items-center gap-3 mb-8">
              <Award className="text-brand-accent w-6 h-6" />
              <h3 className="text-xl font-semibold text-white">Certificaciones Elite</h3>
            </div>
            <div className="grid gap-4">
              {CERTIFICATIONS.map((cert, idx) => {
                const isLink = !!cert.link;
                const Wrapper = isLink ? motion.a : motion.div;
                const props = isLink ? {
                    href: cert.link,
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className: "bg-brand-dark/50 p-6 rounded-xl border border-white/5 hover:border-brand-accent/30 transition-colors flex items-start gap-4 cursor-pointer group hover:bg-white/5 relative"
                } : {
                    className: "bg-brand-dark/50 p-6 rounded-xl border border-white/5 hover:border-brand-accent/30 transition-colors flex items-start gap-4"
                };

                return (
                  // @ts-ignore - Framer motion dynamic component types
                  <Wrapper
                    key={cert.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    viewport={{ once: true }}
                    {...props}
                  >
                    <div className="w-12 h-12 shrink-0 rounded-lg bg-white/5 flex items-center justify-center text-2xl font-serif text-gray-300 overflow-hidden relative z-10">
                      {cert.iconType === 'HARVARD' ? (
                        <img 
                          src="https://identity.hbs.edu/wp-content/uploads/2022/11/Frame-5-1.jpg" 
                          alt="Harvard Business School" 
                          className="w-full h-full object-cover"
                        />
                      ) : cert.iconType === 'MIT' ? (
                        <img 
                          src="https://photos.prnewswire.com/prnfull/20141117/158975LOGO" 
                          alt="MIT Sloan" 
                          className="w-full h-full object-cover"
                        />
                      ) : cert.iconType === 'GOOGLE' ? (
                        <img 
                          src="https://blog.maplink.global/wp-content/uploads/2021/12/google-cloud.jpg" 
                          alt="Google Cloud" 
                          className="w-full h-full object-cover"
                        />
                      ) : null}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className={`text-lg font-bold text-white ${isLink ? 'group-hover:text-brand-accent transition-colors' : ''}`}>
                            {cert.institution}
                        </h4>
                        {isLink && <ExternalLink className="w-4 h-4 text-gray-500 group-hover:text-brand-accent opacity-0 group-hover:opacity-100 transition-all absolute right-4 top-4 sm:static sm:right-auto sm:top-auto" />}
                      </div>
                      <p className="text-brand-accent text-sm font-medium">{cert.program}</p>
                      <div className="mt-2 flex items-center gap-2 text-xs text-gray-500">
                        <CheckCircle2 className="w-3 h-3 text-green-500" /> Verificado
                      </div>
                    </div>
                  </Wrapper>
                );
              })}
            </div>

            {/* Metrics Highlight */}
            <div className="mt-10 p-6 rounded-xl bg-gradient-to-r from-blue-900/20 to-brand-accent/10 border border-blue-500/20">
              <h4 className="text-sm uppercase tracking-wider text-gray-400 mb-4">Impacto Financiero</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-2xl font-mono text-white font-bold">LTV:CAC</div>
                  <div className="text-xs text-gray-500">Optimización Core</div>
                </div>
                <div>
                  <div className="text-2xl font-mono text-white font-bold">Churn</div>
                  <div className="text-xs text-gray-500">Reducción Sistémica</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TrustSection;