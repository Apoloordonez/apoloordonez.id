import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  X, 
  FileSignature, 
  Scale, 
  CreditCard, 
  Cpu, 
  AlertTriangle, 
  ChevronRight, 
  ScrollText,
  Clock,
  ShieldAlert
} from 'lucide-react';

interface TermsOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

const TERMS_SECTIONS = [
  {
    id: 'acceptance',
    title: '1. Aceptación de Términos',
    content: 'Al contratar los servicios de ApoloOrdonez Growth Engineering (ya sea mediante pago directo, firma de propuesta o inicio de trabajos), usted (el "Cliente") acepta vincularse legalmente por estos Términos de Servicio. Estos protocolos rigen toda relación comercial y prevalecen sobre comunicaciones informales.'
  },
  {
    id: 'scope',
    title: '2. Alcance & Entregables',
    content: 'Los servicios se limitan estrictamente a lo detallado en la Propuesta Comercial aprobada o la descripción del servicio en el sitio web. No garantizamos resultados específicos de ventas (ROAS/ROI) ya que estos dependen de factores externos (mercado, producto, equipo de ventas del Cliente). Garantizamos la ejecución técnica impecable y la estrategia basada en datos.'
  },
  {
    id: 'payments',
    title: '3. Pagos & Facturación',
    content: 'La viabilidad financiera es pre-requisito para la ejecución técnica. Operamos bajo un modelo de "Reserva de Capacidad".'
  },
  {
    id: 'ip',
    title: '4. Propiedad Intelectual (IP)',
    content: 'Distinguimos entre "Entregables Finales" y "Metodología". El Cliente posee los datos y creativos finales. La Agencia retiene la propiedad de los métodos.'
  },
  {
    id: 'sla',
    title: '5. SLA & Disponibilidad',
    content: 'Nuestro equipo opera de Lunes a Viernes, 09:00 - 18:00 (GMT-5). Las solicitudes de soporte se gestionan mediante sistema de tickets o email oficial.'
  },
  {
    id: 'liability',
    title: '6. Limitación de Responsabilidad',
    content: 'ApoloOrdonez no se hace responsable por: (a) Bloqueos de cuentas publicitarias por parte de Meta/Google/TikTok (aunque asesoramos para evitarlos), (b) Caídas de servidores de terceros, (c) Pérdidas de lucro cesante derivadas de interrupciones de plataformas externas.'
  }
];

const TermsOverlay: React.FC<TermsOverlayProps> = ({ isOpen, onClose }) => {
  const [activeSection, setActiveSection] = useState(TERMS_SECTIONS[0].id);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
  }, [isOpen]);

  const scrollToSection = (id: string) => {
    setActiveSection(id);
    const element = document.getElementById(`terms-${id}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: '100%' }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="fixed inset-0 z-[100] flex flex-col bg-brand-dark/95 backdrop-blur-xl overflow-hidden"
    >
      {/* Background Grid Pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808008_1px,transparent_1px),linear-gradient(to_bottom,#80808008_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none"></div>

      {/* Top Bar */}
      <div className="relative z-10 flex items-center justify-between px-6 py-4 border-b border-white/10 bg-brand-dark/50">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-purple-500/10 rounded-lg border border-purple-500/20">
            <FileSignature className="w-5 h-5 text-purple-400 animate-pulse" />
          </div>
          <div>
            <h2 className="text-white font-mono font-bold tracking-tight">SLA & TERMS PROTOCOLS</h2>
            <p className="text-[10px] text-gray-500 font-mono uppercase tracking-widest">Master Service Agreement v3.0</p>
          </div>
        </div>
        
        <button 
          onClick={onClose}
          className="p-2 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition-colors group border border-transparent hover:border-white/10"
        >
          <X className="w-6 h-6 group-hover:rotate-90 transition-transform duration-300" />
        </button>
      </div>

      {/* Main Layout */}
      <div className="flex-1 flex overflow-hidden relative z-10">
        
        {/* Sidebar Navigation (Desktop) */}
        <div className="hidden lg:block w-1/4 min-w-[300px] border-r border-white/10 p-6 overflow-y-auto bg-black/20">
          <div className="mb-8">
            <p className="text-xs font-mono text-gray-500 mb-4 uppercase tracking-wider">Cláusulas Contractuales</p>
            <nav className="space-y-1">
              {TERMS_SECTIONS.map((section) => (
                <button
                  key={section.id}
                  onClick={() => scrollToSection(section.id)}
                  className={`w-full text-left px-4 py-3 rounded-lg text-sm font-medium transition-all flex items-center justify-between group ${
                    activeSection === section.id 
                      ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20' 
                      : 'text-gray-400 hover:bg-white/5 hover:text-white border border-transparent'
                  }`}
                >
                  <span className="truncate mr-2">{section.title}</span>
                  {activeSection === section.id && (
                    <motion.div layoutId="activeTermsIndicator">
                      <ChevronRight className="w-4 h-4" />
                    </motion.div>
                  )}
                </button>
              ))}
            </nav>
          </div>

          {/* Legal Stats */}
          <div className="p-4 rounded-xl bg-white/5 border border-white/5 space-y-3">
            <div className="flex items-center gap-3 text-xs text-gray-400">
              <Scale className="w-4 h-4 text-purple-400" />
              <span>Jurisdicción: Ecuador / USA</span>
            </div>
            <div className="flex items-center gap-3 text-xs text-gray-400">
              <Clock className="w-4 h-4 text-brand-accent" />
              <span>SLA Response: 24h</span>
            </div>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto scroll-smooth p-6 lg:p-12 relative">
            <div className="max-w-3xl mx-auto">
                {/* Header */}
                <div className="mb-12 p-6 rounded-2xl bg-gradient-to-br from-purple-500/5 to-transparent border border-purple-500/20">
                    <div className="flex items-start gap-4">
                        <ScrollText className="w-8 h-8 text-purple-400 shrink-0 mt-1" />
                        <div>
                            <h1 className="text-2xl md:text-3xl font-bold text-white mb-2">Términos de Servicio y Acuerdo de Nivel de Servicio (SLA)</h1>
                            <p className="text-gray-400 text-sm leading-relaxed">
                                Este documento constituye un acuerdo legal vinculante. Léalo detenidamente. La ingeniería de crecimiento requiere reglas claras para operar a máxima velocidad.
                            </p>
                        </div>
                    </div>
                </div>

                {/* Sections */}
                <div className="space-y-16">
                    {TERMS_SECTIONS.map((section) => (
                        <div key={section.id} id={`terms-${section.id}`} className="scroll-mt-24">
                            <h3 className="text-xl font-mono text-white mb-4 flex items-center gap-3">
                                <span className="w-1.5 h-6 bg-purple-500 rounded-full"></span>
                                {section.title}
                            </h3>
                            <div className="prose prose-invert prose-p:text-gray-300 prose-p:font-sans prose-p:leading-7 max-w-none">
                                <p>{section.content}</p>
                            </div>
                            
                            {/* Special Logic for Payments Box */}
                            {section.id === 'payments' && (
                                <div className="mt-6 p-5 border border-amber-500/30 bg-amber-500/5 rounded-xl flex gap-4">
                                    <div className="p-2 bg-amber-500/10 rounded-lg h-fit">
                                        <CreditCard className="w-5 h-5 text-amber-400" />
                                    </div>
                                    <div>
                                        <h4 className="text-sm font-bold text-amber-400 mb-1 uppercase tracking-wide">Protocolo de Pagos</h4>
                                        <p className="text-sm text-gray-300">
                                            Todos los servicios se facturan y cobran por adelantado (Mes Corriente). 
                                            La falta de pago suspende automáticamente cualquier campaña activa en un plazo de 48 horas.
                                            <strong> No existen reembolsos</strong> por trabajo ya ejecutado o configuración de campañas.
                                        </p>
                                    </div>
                                </div>
                            )}

                             {/* Special Logic for IP Box */}
                             {section.id === 'ip' && (
                                <div className="mt-6 p-5 border border-brand-accent/30 bg-brand-accent/5 rounded-xl flex gap-4">
                                    <div className="p-2 bg-brand-accent/10 rounded-lg h-fit">
                                        <Cpu className="w-5 h-5 text-brand-accent" />
                                    </div>
                                    <div>
                                        <h4 className="text-sm font-bold text-brand-accent mb-1 uppercase tracking-wide">Tecnología & IA</h4>
                                        <p className="text-sm text-gray-300">
                                            El Cliente es dueño de los resultados (leads, data, diseños finales). 
                                            <strong> ApoloOrdonez retiene la propiedad intelectual</strong> de los Agentes de IA, 
                                            Estructuras de Prompts, y Metodologías de "Growth Engineering" utilizadas para generar dichos resultados.
                                        </p>
                                    </div>
                                </div>
                            )}

                            {/* Special Logic for Liability */}
                            {section.id === 'liability' && (
                                <div className="mt-6 p-4 border-l-2 border-red-500 bg-red-500/5 rounded-r-lg flex items-center gap-3">
                                    <ShieldAlert className="w-5 h-5 text-red-500 shrink-0" />
                                    <p className="text-sm text-gray-400 m-0">
                                        No controlamos los algoritmos de terceros. Las decisiones de "Baneo" por parte de Meta/Google son finales y ajenas a nuestra gestión, aunque siempre actuaremos en cumplimiento de sus políticas.
                                    </p>
                                </div>
                            )}
                        </div>
                    ))}
                </div>

                {/* Footer Signature */}
                <div className="mt-20 pt-10 border-t border-white/10 text-center">
                    <p className="text-gray-500 text-sm">
                        Al continuar navegando o contratando, usted ratifica este acuerdo. <br />
                        <span className="text-purple-400 font-mono text-xs mt-2 inline-block">ID CONTRATO: PUBLIC-SLA-GEN-2024</span>
                    </p>
                </div>
            </div>
        </div>
      </div>
    </motion.div>
  );
};

export default TermsOverlay;