import React, { useState, useEffect } from 'react';
import { Menu, X, Infinity } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    e.preventDefault();
    setIsOpen(false);
    
    if (targetId === 'top') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    const element = document.getElementById(targetId);
    if (element) {
      const headerOffset = 80; // Altura del navbar
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${scrolled || isOpen ? 'bg-brand-dark/90 backdrop-blur-md border-b border-white/5' : 'bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center gap-4">
            {/* Vector Brand Logo */}
            <a 
                href="#" 
                onClick={(e) => handleNavClick(e, 'top')}
                className="flex items-center group select-none"
            >
                <span className="text-2xl font-serif font-bold text-white tracking-tight">Apol</span>
                <Infinity className="w-8 h-8 text-gray-500 mx-px group-hover:text-brand-accent transition-colors duration-300" strokeWidth={2.5} />
                <span className="text-2xl font-serif font-bold text-white tracking-tight">rdonez</span>
            </a>
            
            <div className="hidden sm:block w-px h-8 bg-white/10"></div>
            <span className="hidden sm:block text-[10px] text-brand-accent uppercase tracking-widest leading-none">
              Growth<br/>Engineering
            </span>
          </div>
          
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              <a 
                href="#services" 
                onClick={(e) => handleNavClick(e, 'services')}
                className="text-gray-300 hover:text-brand-accent transition-colors px-3 py-2 rounded-md text-sm font-medium"
              >
                Soluciones
              </a>
              <a 
                href="#expertise" 
                onClick={(e) => handleNavClick(e, 'expertise')}
                className="text-gray-300 hover:text-brand-accent transition-colors px-3 py-2 rounded-md text-sm font-medium"
              >
                Trayectoria
              </a>
              <a 
                href="#contact" 
                onClick={(e) => handleNavClick(e, 'contact')}
                className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-md text-sm font-medium transition-all border border-white/5"
              >
                Consultar
              </a>
            </div>
          </div>

          <div className="-mr-2 flex md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700 focus:outline-none"
              aria-expanded={isOpen}
            >
              {isOpen ? <X className="block h-6 w-6" /> : <Menu className="block h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-brand-dark border-b border-white/5 shadow-xl">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <a 
              href="#services" 
              onClick={(e) => handleNavClick(e, 'services')}
              className="text-gray-300 hover:text-white hover:bg-white/5 block px-3 py-4 rounded-md text-base font-medium border-b border-white/5 last:border-0"
            >
              Soluciones
            </a>
            <a 
              href="#expertise" 
              onClick={(e) => handleNavClick(e, 'expertise')}
              className="text-gray-300 hover:text-white hover:bg-white/5 block px-3 py-4 rounded-md text-base font-medium border-b border-white/5 last:border-0"
            >
              Trayectoria
            </a>
            <a 
              href="#contact" 
              onClick={(e) => handleNavClick(e, 'contact')}
              className="text-brand-accent hover:text-white hover:bg-white/5 block px-3 py-4 rounded-md text-base font-medium font-mono"
            >
              > Consultar
            </a>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;