import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Linkedin, 
  Github,
  ShieldCheck, 
  Lock, 
  Server, 
  Calendar, 
  Zap,
  CheckCircle,
  Loader2
} from 'lucide-react';

interface FooterProps {
  onOpenPrivacy: () => void;
  onOpenTerms: () => void;
}

// Custom Skool Logo Component
const SkoolIcon = ({ className = "w-5 h-5" }: { className?: string }) => (
  <svg 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    className={className} 
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M2.6 10.4c0-4.6 1.8-6.2 4.4-7.2.5-.2 1.4-.3 1.9-.3 2.5 0 4.7 1.2 6.1 3.3.6.9.9 1.8.9 2.8v.2c0 .9.6 1.5 1.5 1.5.8 0 1.4-.6 1.4-1.4 0-2.4-1.7-5.8-5.3-7.5C11.6.9 9.2.7 7.1 1 3.2 1.5.1 4.3.1 8.7c0 3 .8 4.9 2.3 6.6 1.4 1.6 3.4 2.3 5.3 2.3h.5c.9 0 1.5-.6 1.5-1.5 0-.8-.6-1.4-1.4-1.4-.9 0-2.4-.4-3.4-1.5-1.2-1.2-1.8-2.6-1.8-4.9h-.1zM18.8 8c-3.1 0-5.1 2.3-5.1 5.3 0 3.1 2.2 5.3 5.1 5.3 2.9 0 5.1-2.2 5.1-5.3 0-3-2.2-5.3-5.1-5.3zm0 8c-1.6 0-2.6-1.2-2.6-2.7 0-1.5.9-2.7 2.6-2.7 1.6 0 2.6 1.2 2.6 2.7 0 1.5-1 2.7-2.6 2.7z" />
  </svg>
);

const Footer: React.FC<FooterProps> = ({ onOpenPrivacy, onOpenTerms }) => {
  const [status, setStatus] = useState<'idle' | 'loading' | 'success'>('idle');
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setStatus('loading');
    
    // Simulate API delay for UX
    setTimeout(() => {
      setStatus('success');
      setEmail('');
      
      // Reset to idle after success message is shown
      setTimeout(() => {
        setStatus('idle');
      }, 3000);
    }, 2000);
  };

  return (
    <footer id="contact" className="bg-brand-dark border-t border-white/5 pt-20 pb-10 relative overflow-hidden">
      {/* Background Grid Effect */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none"></div>
      
      {/* Radial Gradient overlay for depth */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-brand-accent/5 blur-[120px] rounded-full pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-20">
          
          {/* Left Column: Manifesto & Brand */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="flex flex-col justify-center"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 tracking-tight">
              ¿Listo para <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-500">escalar?</span>
            </h2>
            
            <p className="text-lg text-gray-400 mb-10 max-w-xl leading-relaxed">
              La ingeniería de crecimiento <span className="text-brand-accent font-semibold">no es magia, es método</span>. 
              Si buscas resultados predecibles y escalables, hablemos de números.
            </p>

            {/* Security Badge */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 pt-8 border-t border-white/10">
              <div className="flex -space-x-2">
                <div className="p-2 bg-brand-gray rounded-full border border-white/10">
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                </div>
                <div className="p-2 bg-brand-gray rounded-full border border-white/10">
                  <Lock className="w-5 h-5 text-emerald-400" />
                </div>
                <div className="p-2 bg-brand-gray rounded-full border border-white/10">
                  <Server className="w-5 h-5 text-emerald-400" />
                </div>
              </div>
              <div>
                <p className="text-xs font-mono text-gray-500 uppercase tracking-wider">
                  Infraestructura Segura & Compliance
                </p>
                <p className="text-[10px] text-gray-600">GDPR / LOPD Compliant Data Handling</p>
              </div>
            </div>
          </motion.div>
          
          {/* Right Column: Glass Card & Actions */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex flex-col items-start lg:items-end"
          >
             {/* Glassmorphism Action Card */}
             <div className="w-full max-w-lg bg-white/5 backdrop-blur-md border border-white/10 p-8 rounded-2xl shadow-2xl shadow-black/50 relative overflow-hidden group mb-10">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-brand-accent to-blue-600"></div>
                
                <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                  <span className="w-2 h-2 bg-brand-accent rounded-full animate-pulse"></span>
                  Contacto Directo
                </h3>
                
                <p className="text-sm text-gray-400 mb-8 leading-relaxed">
                  Conversemos sobre cómo escalar tus resultados. En esta sesión estratégica de 15 minutos, 
                  analizaremos tus oportunidades de crecimiento y te mostraré el sistema exacto para aumentar 
                  tu rentabilidad sin depender del azar.
                </p>

                <a 
                  href="https://wa.me/593962610510"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="relative w-full group overflow-hidden bg-gradient-to-r from-brand-accent to-blue-500 text-brand-dark font-bold py-4 px-6 rounded-lg flex items-center justify-center gap-3 transition-all hover:shadow-[0_0_20px_rgba(102,252,241,0.3)] hover:scale-[1.02]"
                >
                  <span className="relative z-10 flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Reservar Auditoría Personalizada
                  </span>
                  {/* Subtle sheen effect */}
                  <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 skew-y-12"></div>
                </a>
             </div>

             {/* Hyper-Dynamic HUD Interface: DataIngestionModule */}
             <div className="w-full max-w-lg">
                {/* Header & Status */}
                <div className="flex items-center justify-between mb-2 px-1">
                    <h4 className="text-white font-bold tracking-tight">Growth Intelligence Log</h4>
                    <div className="flex items-center gap-2">
                        <span className={`w-1.5 h-1.5 rounded-full transition-colors duration-300 ${status === 'loading' ? 'bg-amber-400 animate-ping' : status === 'success' ? 'bg-emerald-400' : 'bg-emerald-500 animate-pulse'}`}></span>
                        <span className="text-[10px] font-mono text-emerald-500/80 tracking-widest">
                            {status === 'idle' ? 'SYSTEM READY' : status === 'loading' ? 'PROCESSING...' : 'ESTABLISHED'}
                        </span>
                    </div>
                </div>

                {/* Input Container */}
                <form onSubmit={handleSubmit} className="relative group">
                    {/* Animated Border Gradient Background */}
                    <div className="absolute -inset-[1px] bg-gradient-to-r from-brand-accent/50 to-blue-600/50 rounded-2xl opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 transition duration-500 blur-sm"></div>
                    
                    {/* Main Glass Housing */}
                    <div className="relative bg-white/5 border border-white/10 rounded-2xl backdrop-blur-md flex items-center p-2 transition-colors overflow-hidden">
                        <input 
                            type="email" 
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder={status === 'success' ? 'Protocolo iniciado correctamente' : "Ingresa tu correo corporativo..."}
                            disabled={status !== 'idle'}
                            className="bg-transparent border-none outline-none text-sm text-white placeholder-gray-500 w-full pl-4 py-3 font-sans disabled:opacity-50"
                        />
                        
                        <button 
                            type="submit"
                            disabled={status !== 'idle' && status !== 'success'}
                            className="ml-2 relative h-10 w-12 rounded-xl flex items-center justify-center overflow-hidden transition-all duration-300 disabled:cursor-not-allowed group/btn"
                        >
                           <AnimatePresence mode='wait'>
                                {status === 'idle' && (
                                    <motion.div
                                        key="idle"
                                        initial={{ scale: 0.8, opacity: 0 }}
                                        animate={{ scale: 1, opacity: 1 }}
                                        exit={{ scale: 0.8, opacity: 0 }}
                                        whileHover={{ scale: 1.1 }}
                                        className="bg-white/10 group-hover/btn:bg-brand-accent group-hover/btn:text-brand-dark text-white p-2 rounded-lg transition-colors w-full h-full flex items-center justify-center"
                                    >
                                        <Zap size={18} fill="currentColor" className="opacity-100" />
                                    </motion.div>
                                )}
                                {status === 'loading' && (
                                    <motion.div
                                         key="loading"
                                         initial={{ scale: 0 }}
                                         animate={{ scale: 1 }}
                                         exit={{ scale: 0 }}
                                    >
                                        <Loader2 className="w-5 h-5 text-brand-accent animate-spin" />
                                    </motion.div>
                                )}
                                {status === 'success' && (
                                    <motion.div
                                         key="success"
                                         initial={{ scale: 0 }}
                                         animate={{ scale: 1 }}
                                         exit={{ scale: 0 }}
                                    >
                                        <CheckCircle className="w-6 h-6 text-emerald-500" />
                                    </motion.div>
                                )}
                           </AnimatePresence>
                        </button>

                        {/* Scanning Line Effect */}
                        <div className="absolute bottom-0 left-0 w-full h-[1px] bg-white/5 overflow-hidden">
                            <motion.div 
                                className="w-1/2 h-full bg-gradient-to-r from-transparent via-brand-accent/50 to-transparent"
                                animate={{ x: ['-100%', '200%'] }}
                                transition={{ duration: 2.5, repeat: Infinity, ease: "linear" }}
                            />
                        </div>
                    </div>
                </form>

                <p className="mt-3 text-xs text-gray-500 pl-1 font-mono">
                    Recibe protocolos de escalamiento semanalmente. Cero spam, 100% estrategia.
                </p>
             </div>
          </motion.div>
        </div>
        
        {/* Footer Bottom */}
        <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-4">
            
             {/* 1. LinkedIn */}
            <a 
              href="https://www.linkedin.com/in/apoloordonez" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="p-2 text-gray-500 hover:text-brand-accent transition-colors"
              aria-label="LinkedIn"
            >
              <Linkedin size={20} />
            </a>

            {/* 2. GitHub */}
            <a 
              href="https://github.com/Apoloordonez11" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="p-2 text-gray-500 hover:text-brand-accent transition-colors"
              aria-label="GitHub"
            >
              <Github size={20} />
            </a>

            {/* 3. Skool */}
            <a 
              href="https://www.skool.com/@christopher-ordonez-5011" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="p-2 text-gray-500 hover:text-brand-accent transition-colors"
              aria-label="Skool"
            >
              <SkoolIcon className="w-5 h-5" />
            </a>

          </div>

          <div className="flex flex-col md:flex-row items-center gap-4 md:gap-8">
            <p className="text-xs text-gray-600 font-mono">
              © {new Date().getFullYear()} Christopher Ordóñez. All rights reserved.
            </p>
            <div className="flex gap-6 text-xs text-gray-500">
              <button 
                onClick={onOpenPrivacy}
                className="hover:text-brand-accent transition-colors text-left"
              >
                Privacy Policy
              </button>
              <button 
                onClick={onOpenTerms}
                className="hover:text-brand-accent transition-colors text-left"
              >
                Terms of Service
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;