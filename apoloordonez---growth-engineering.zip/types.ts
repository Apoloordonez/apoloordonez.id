import { LucideIcon } from "lucide-react";

export enum ServiceCategory {
  VALIDATION = 'Validation & Traction',
  GROWTH = 'Growth & Acceleration',
  ENTERPRISE = 'Enterprise & Corporate'
}

export interface ServiceItem {
  id: string;
  title: string;
  totalInvestment: string; // The headline price
  fee: string; // Your revenue
  adSpend: string; // Client budget
  setupFee?: string; // Additional one-time or setup costs
  description: string;
  deliverables: string[];
  category: ServiceCategory;
  isPremium: boolean;
  isPopular?: boolean;
  icon: LucideIcon;
  bookingUrl?: string; // Custom URL for the CTA button
}

export interface ExperienceItem {
  id: string;
  company: string;
  role: string;
  description: string;
  year: string;
}

export interface CertificationItem {
  id: string;
  institution: string;
  program: string;
  iconType: 'HARVARD' | 'MIT' | 'GOOGLE';
  link?: string;
}

export interface StatItem {
  label: string;
  value: string;
  description: string;
}