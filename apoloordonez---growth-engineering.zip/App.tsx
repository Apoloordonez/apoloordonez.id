import React, { useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import TrustSection from './components/TrustSection';
import Services from './components/Services';
import Footer from './components/Footer';
import PrivacyOverlay from './components/PrivacyOverlay';
import TermsOverlay from './components/TermsOverlay';

function App() {
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [isTermsOpen, setIsTermsOpen] = useState(false);

  return (
    <div className="bg-brand-dark min-h-screen text-brand-text font-sans selection:bg-brand-accent selection:text-brand-dark">
      <Navbar />
      <main>
        <HeroSection />
        <TrustSection />
        <Services />
      </main>
      <Footer 
        onOpenPrivacy={() => setIsPrivacyOpen(true)} 
        onOpenTerms={() => setIsTermsOpen(true)}
      />
      
      <AnimatePresence>
        {isPrivacyOpen && (
          <PrivacyOverlay 
            key="privacy"
            isOpen={isPrivacyOpen} 
            onClose={() => setIsPrivacyOpen(false)} 
          />
        )}
        {isTermsOpen && (
          <TermsOverlay 
            key="terms"
            isOpen={isTermsOpen} 
            onClose={() => setIsTermsOpen(false)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;