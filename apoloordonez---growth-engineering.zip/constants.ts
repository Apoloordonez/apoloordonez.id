import { 
  Rocket, 
  Target, 
  TrendingUp, 
  Cpu, 
  Building2, 
  Globe2
} from "lucide-react";
import { ServiceItem, ServiceCategory, ExperienceItem, CertificationItem, StatItem } from "./types";

export const SERVICES: ServiceItem[] = [
  {
    id: 'starter',
    title: 'Starter Launch',
    totalInvestment: '$750/mes',
    fee: '$500',
    adSpend: '$250 (Custom)',
    description: 'Para negocios en etapa temprana que necesitan validar su oferta rápidamente con datos reales.',
    deliverables: [
      'Auditoría Digital Express (Situación actual)',
      'Estrategia Meta Core (Mensajes/Leads)',
      'Gestión de Meta Ads (FB & IG)',
      'Tabla de KPIs automatizada (Looker Studio)',
      'Reporte Mensual Asincrónico (Video)'
    ],
    category: ServiceCategory.VALIDATION,
    isPremium: false,
    icon: Rocket,
    bookingUrl: 'https://forms.gle/AiqH1Y2WTbiTpxgY6'
  },
  {
    id: 'market-fit',
    title: 'Market Fit',
    totalInvestment: '$1,600/mes',
    fee: '$1,000',
    adSpend: '$600 (Custom)',
    description: 'Para negocios con validación inicial que buscan diversificar canales y consolidar tracción.',
    deliverables: [
      'Incluye todo del Servicio "Starter Launch"',
      'Benchmark Competitivo de Mercado',
      'Estrategia Multicanal (Meta + Google Ads)',
      'SEO On-page esencial (Mantenimiento ligero)',
      'Embudo de Ventas V1 (Landing Page básica)',
      'Reporte Quincenal (Call 15 min)'
    ],
    category: ServiceCategory.VALIDATION,
    isPremium: false,
    isPopular: true,
    icon: Target,
    bookingUrl: 'https://forms.gle/WiKdu67TQbmQmw2Z8'
  },
  {
    id: 'business-scaling',
    title: 'Business Scaling',
    totalInvestment: '$3,250/mes',
    fee: '$1,750',
    adSpend: '$1,500 (Custom)',
    description: 'Escalamiento agresivo para PyMEs con equipos de ventas que requieren volumen de MQLs/SQLs.',
    deliverables: [
      'Incluye todo de los Servicios "Starter Launch" y "Market Fit"',
      'Performance Marketing 360° (Enfoque ROAS)',
      'Agile Funnels (Testing rápido de ofertas)',
      'AI Creative Suite (Generación de anuncios)',
      'Integración CRM & Automatización Nivel 1',
      'Chatbot IA de atención al cliente'
    ],
    category: ServiceCategory.GROWTH,
    isPremium: false,
    icon: TrendingUp,
    bookingUrl: 'https://forms.gle/CmNfGL1FquG5hkM8A'
  },
  {
    id: 'fractional-growth',
    title: 'Fractional Growth',
    totalInvestment: '$5,500/mes',
    fee: '$2,500',
    adSpend: '$3,000 (Custom)',
    setupFee: '$2,500 pago único + $100/mes',
    description: 'Dirección estratégica completa. Tu socio de crecimiento para dominar el nicho con tecnología avanzada.',
    deliverables: [
      'Incluye todo del Servicio "Business Scaling"',
      'Rol: Fractional Head of Growth (Dirección Estratégica)',
      'Paid Media High-Performance: Estrategias avanzadas',
      'Ingeniería de Embudos: Lead scoring & Nurture',
      'BI: Dashboards LTV, CAC, Churn & Proyecciones',
      'AI Agents Ecosystem (RAG): Soporte/Ventas 24/7'
    ],
    category: ServiceCategory.GROWTH,
    isPremium: true,
    icon: Cpu,
    bookingUrl: 'https://forms.gle/T443CVdLCERhSBCb8'
  },
  {
    id: 'corporate-trans',
    title: 'Corporate Transformation',
    totalInvestment: 'Custom',
    fee: '$5,000',
    adSpend: '$25k - $100k (Custom)',
    description: 'Modernización de la infraestructura de adquisición y gobernanza de datos para grandes organizaciones.',
    deliverables: [
      'Estrategia CDP (Gobierno de Datos)',
      'RevOps (Alineación Mkt-Ventas-Servicio)',
      'In-Housing (Capacitación de equipos internos)',
      'Automatización de procesos operativos (IA)'
    ],
    category: ServiceCategory.ENTERPRISE,
    isPremium: false,
    icon: Building2,
    bookingUrl: 'https://calendly.com/freeconsultoryinitialcomkt/consultoria-personalizada-para-corporate-transformation'
  },
  {
    id: 'global-dominance',
    title: 'Global Dominance',
    totalInvestment: 'Custom',
    fee: '$10,000',
    adSpend: '$500k - $1M (Custom)',
    description: 'Arquitectura de expansión global y modelos predictivos para multinacionales.',
    deliverables: [
      'Estrategia Cross-Border & Localización',
      'Marketing Mix Modeling (MMM)',
      'Arquitectura Enterprise AI en la Nube',
      'Brand Compliance Global'
    ],
    category: ServiceCategory.ENTERPRISE,
    isPremium: true,
    icon: Globe2,
    bookingUrl: 'https://calendly.com/freeconsultoryinitialcomkt/consultoria-personalizada-para-corporate-transformation'
  }
];

export const EXPERIENCE: ExperienceItem[] = [
  {
    id: 'saludsa',
    company: 'SaludS.A.',
    role: 'Director de Estrategia Digital',
    description: 'Liderazgo en transformación HealthTech. Reingeniería de canales de pauta y reducción sistemática del CAC mediante modelos de atribución avanzados.',
    year: 'Directivo'
  },
  {
    id: 'sodig',
    company: 'Sodig S.A.',
    role: 'Consultor Estratégico 360°',
    description: 'Pionero en el uso de IA Generativa para optimización en tiempo real. Diseño de estructuras "Full Funnel" para productos High-Ticket.',
    year: 'Consultor'
  },
  {
    id: 'ecuasmart',
    company: 'Ecuasmart Healthcare',
    role: 'Estratega Digital Publicitario',
    description: 'Consolidación de ROI > 700% y margen de beneficio del 250% por suscripción en modelo SaaS, mediante automatización de marketing.',
    year: 'Lead'
  },
  {
    id: 'blue-channel',
    company: 'Blue Channel Latam',
    role: 'Director Digital 360°',
    description: 'Expansión LATAM y estrategias Drive-to-Store. Implementación de neuromarketing para captación masiva de leads de alto perfil.',
    year: 'Directivo'
  },
  {
    id: 'decameron',
    company: 'Decameron Hotels',
    role: 'Trafficker Digital Senior',
    description: 'Gestión de presupuestos masivos y optimización de ROAS para mercados Latam. Segmentación avanzada por comportamiento de compra.',
    year: 'Senior'
  },
  {
    id: 'holding-medico',
    company: 'Holding Médico (12+ Clínicas)',
    role: 'Director de Marketing Digital',
    description: 'Gestión centralizada para 12 clínicas. Ecosistema de 3 embudos diferenciados (Aspiracional, Autoridad, Conversión) logrando +325% en rentabilidad.',
    year: 'Director'
  }
];

export const CERTIFICATIONS: CertificationItem[] = [
  {
    id: 'hbs',
    institution: 'Harvard Business School',
    program: 'Growth Strategy',
    iconType: 'HARVARD',
    link: 'https://drive.google.com/file/d/101Yi-RYD-sZidUThccQpa0QlR9smBCii/view?usp=drive_link'
  },
  {
    id: 'mit',
    institution: 'MIT Sloan',
    program: 'Data-Driven Marketing',
    iconType: 'MIT',
    link: 'https://drive.google.com/file/d/14u1eyw6FmAjDorbib29MK-SN0o2fD4_n/view?usp=drive_link'
  },
  {
    id: 'google',
    institution: 'Google Cloud',
    program: 'Machine Learning Specialization',
    iconType: 'GOOGLE'
  }
];

export const STATS: StatItem[] = [
  {
    label: 'ROI Promedio',
    value: '>700%',
    description: 'Retorno sobre inversión publicitaria gestionada.'
  },
  {
    label: 'Experiencia',
    value: '+7 Años',
    description: 'Transformando centros de costos en centros de ingresos.'
  },
  {
    label: 'Enfoque',
    value: 'LTV:CAC',
    description: 'Optimización basada en rentabilidad real, no métricas de vanidad.'
  }
];

// Animation arrays
export const ROTATING_FOCUS = [
  "Data-Driven",
  "Full Funnel",
  "LTV Centric",
  "Experimentation",
  "RevOps"
];

export const ROTATING_STACK = [
  "Next-Gen AI",
  "Python & SQL",
  "React & Node",
  "Looker Studio",
  "Google Cloud"
];